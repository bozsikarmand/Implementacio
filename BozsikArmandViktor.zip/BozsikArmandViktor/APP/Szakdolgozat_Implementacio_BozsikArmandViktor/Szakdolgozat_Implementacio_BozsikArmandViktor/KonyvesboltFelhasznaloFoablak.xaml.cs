﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using System.Net.Mail;
using System.Net;
using System.Net.Mime;
using System.Windows.Media.Animation;
using System.Diagnostics;

namespace Szakdolgozat_Implementacio_BozsikArmandViktor
{
    /// <summary>
    /// Interaction logic for KonyvesboltFelhasznaloFoablak.xaml
    /// </summary>
    public partial class KonyvesboltFelhasznaloFoablak : Window
    {
        private int ID;
        public Konyv konyvSora;
        public KonyvesboltFelhasznaloFoablak(int ID)
        {
            this.ID = ID;
            InitializeComponent();
            DataGridFeltoltese();
            //DataGridKosarFeltoltese();
        }

        /// <summary>
        /// Letrehozom a DataContextet, mely az objektum-relacios modellt reprezentalja
        /// Az osszes konyv lekerdezesre kerul
        /// A dataGrid forrasa a lekerdezes eredmenytablaja lesz
        /// </summary>
        private void DataGridFeltoltese()
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var konyv = (from k in adatbazis.Konyvs select k);
            dataGridKonyv.ItemsSource = konyv;
        }
        private void DataGridKosarFeltoltese()
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var kosar = (from k in adatbazis.FelhasznaloKonyvs select k);
            dataGridKosar.ItemsSource = kosar;
        }
        private void ElemKosarbaHelyezese()
        {
            try
            {
                AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
                Konyv konyvSora = dataGridKonyv.SelectedItem as Konyv;

                var konyv = (from k in adatbazis.Konyvs
                             where k.ID == konyvSora.ID
                             select k).Single();

                FelhasznaloKonyv kosar = new FelhasznaloKonyv();

                kosar.FelhasznaloID = ID;
                kosar.KonyvID = konyv.ID;

                dataGridKosar.Items.Add(konyv);
                adatbazis.FelhasznaloKonyvs.InsertOnSubmit(kosar);
                adatbazis.SubmitChanges();

                buttonTovabbAzESzamlaAtvetelehez.IsEnabled = true;
                buttonTovabbAzESzamlaAtvetelehez.Foreground = new SolidColorBrush(Colors.White);
                buttonKosarba.IsEnabled = false;
                buttonKosarba.Foreground = new SolidColorBrush(Colors.Black);
                buttonKosarbol.IsEnabled = true;
                MessageBox.Show("Sikeresen kosarba helyezte a termeket!", "Koszonjuk!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception)
            {
                dataGridKosar.Items.Clear();
                MessageBox.Show("A kivalasztott e-konyvet mar egyszer megvette!", "Figyelem", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ElemKiveteleAKosarbol()
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            Konyv kosarSora = dataGridKosar.SelectedItem as Konyv;

            var kosar = (from ks
                         in adatbazis.FelhasznaloKonyvs
                         where ks.KonyvID == kosarSora.ID &&
                               ks.FelhasznaloID == ID
                         select ks).Single();

            dataGridKosar.Items.Remove(kosarSora);
            adatbazis.FelhasznaloKonyvs.DeleteOnSubmit(kosar);
            adatbazis.SubmitChanges();

            MessageBox.Show("Sikeresen eltavolitotta a kosarbol a termeket!", "Megerosites", MessageBoxButton.OK, MessageBoxImage.Information);

            if (dataGridKosar.Items.IsEmpty == true)
            {
                buttonKosarba.IsEnabled = true;
                buttonTovabbAzESzamlaAtvetelehez.IsEnabled = false;
                buttonTovabbAzESzamlaAtvetelehez.Foreground = new SolidColorBrush(Colors.White);
            }
        }

        private void menuItemKapcsolatfelvetel_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltFelhasznaloKapcsolatfelvetel konyvesboltFelhasznaloKapcsolatfelvetel = new KonyvesboltFelhasznaloKapcsolatfelvetel(ID);
            konyvesboltFelhasznaloKapcsolatfelvetel.Show();
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dataGridKonyv.CanUserAddRows = false;
            dataGridKosar.CanUserAddRows = false;
            buttonKosarba.IsEnabled = false;
            buttonKosarba.Foreground = new SolidColorBrush(Colors.Black);
            buttonKosarbol.IsEnabled = false;
            buttonKosarbol.Foreground = new SolidColorBrush(Colors.Black);

            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var felhasznaloUdvozles = (from f in adatbazis.Felhasznalos
                                       where f.ID == ID
                                       select f).Single();

            labelFelhasznaloUdvozles.Content = String.Concat("Udvozlom, ", felhasznaloUdvozles.Vezeteknev, " ", felhasznaloUdvozles.Keresztnev, "!");

            Latogatas latogatas = new Latogatas();
            latogatas.Datum = DateTime.Now;
            latogatas.FelhasznaloID = ID;
            latogatas.Vasarolt = false;

            adatbazis.Latogatas.InsertOnSubmit(latogatas);
            adatbazis.SubmitChanges();

            var felhasznaloTorzsvasarlo = (from t in adatbazis.Latogatas
                                           where t.FelhasznaloID == ID && t.Vasarolt == true
                                           select t).Count();

            if (felhasznaloTorzsvasarlo >= 5)
            {
                labelFelhasznaloTorzsvasarlo.Content = "On mar a torzsvasarloi program tagja!";
            }
            else
            {
                labelFelhasznaloTorzsvasarlo.Content = "On meg nem tagja torzsvasarloi programunknak!";
            }
        }

        private void buttonKosarba_Click(object sender, RoutedEventArgs e)
        {
            ElemKosarbaHelyezese();
        }

        private void buttonTovabbAzESzamlaAtvetelehez_Click(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();

            var vasarlasBeallitasa = (from f in adatbazis.Latogatas
                                      where f.FelhasznaloID == ID
                                      orderby f.Datum descending
                                      select f).First();

            vasarlasBeallitasa.Vasarolt = true;
            adatbazis.SubmitChanges();
            MessageBox.Show("Sikeres vasarlas! A kovetkezo oldalon veheti at a rendeleserol keszult e-szamlat!", "Koszonjuk!", MessageBoxButton.OK, MessageBoxImage.Information);

            konyvSora = dataGridKosar.Items[0] as Konyv;
            KonyvesboltFelhasznaloRendelesOsszesites konyvesboltFelhasznaloRendelesOsszesites = new KonyvesboltFelhasznaloRendelesOsszesites(ID, konyvSora);
            konyvesboltFelhasznaloRendelesOsszesites.Show();
            this.Close();            
        }

        private void buttonKosarbol_Click(object sender, RoutedEventArgs e)
        {
            ElemKiveteleAKosarbol();
        }

        private void textBoxKereses_TextChanged(object sender, TextChangedEventArgs e)
        {
            var ertek = textBoxKereses.Text.Trim();
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            try
            {
                var keresesiLekerdezes = (from k in adatbazis.Konyvs
                                          where
                                                k.Almufaj.Contains(ertek) ||
                                                k.Ar.Equals(ertek) ||
                                                k.Cim.Contains(ertek) ||
                                                k.Fajlmeret.Equals(ertek) ||
                                                k.ISBN.Contains(ertek) ||
                                                k.KiadasiEv.Equals(ertek) ||
                                                k.Kiado.Contains(ertek) ||
                                                k.Mufaj.Contains(ertek) ||
                                                k.Nyelv.Contains(ertek) ||
                                                k.Oldalszam.Equals(ertek)
                                          select k).ToList();


                if (String.IsNullOrEmpty(textBoxKereses.Text) || textBoxKereses.Text == "")
                {
                    var konyv = (from k in adatbazis.Konyvs select k);
                    dataGridKonyv.ItemsSource = konyv;
                }
                else
                {
                    dataGridKonyv.ItemsSource = keresesiLekerdezes;
                }
            }
            catch (Exception)
            {
                var konyv = (from k in adatbazis.Konyvs select k);
                dataGridKonyv.ItemsSource = konyv;
            }
        }

        private void menuItemFelhasznaloiAdatok_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltFelhasznaloAdatai konyvesboltFelhasznaloAdatai = new KonyvesboltFelhasznaloAdatai(ID);
            konyvesboltFelhasznaloAdatai.Show();
            this.Close();
        }

        private void menuItemLegujabbKonyvek_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltFelhasznaloLegujabbKonyvek konyvesboltFelhasznaloLegujabbKonyvek = new KonyvesboltFelhasznaloLegujabbKonyvek(ID);
            konyvesboltFelhasznaloLegujabbKonyvek.Show();
            this.Close();
        }

        private void menuItemAjanlottKonyvek_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltFelhasznaloAjanlottKonyvek konyvesboltFelhasznaloAjanlottKonyvek = new KonyvesboltFelhasznaloAjanlottKonyvek(ID);
            konyvesboltFelhasznaloAjanlottKonyvek.Show();
            this.Close();
        }

        private void dataGridKonyv_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dataGridKonyv.SelectedIndex != -1)
            {
                buttonKosarba.IsEnabled = true;
                buttonKosarba.Foreground = new SolidColorBrush(Colors.White);
            }
            else
            {
                buttonKosarba.IsEnabled = false;
                buttonKosarba.Foreground = new SolidColorBrush(Colors.Black);
                buttonKosarbol.IsEnabled = false;
            }
        }

        private void dataGridKosar_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dataGridKosar.SelectedIndex != -1)
            {
                buttonKosarbol.IsEnabled = true;
                buttonKosarbol.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFD9442A"));
                buttonKosarbol.Foreground = new SolidColorBrush(Colors.White);
            }
            else
            {
                buttonKosarbol.IsEnabled = false;
                buttonKosarbol.Background = new SolidColorBrush(Colors.White);
                buttonKosarbol.Foreground = new SolidColorBrush(Colors.Black);
            }
        }
    }
}
