﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Szakdolgozat_Implementacio_BozsikArmandViktor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            SplashScreen toltokepernyo = new SplashScreen("logo.ico");
            toltokepernyo.Show(false);
            Thread.Sleep(800);
            toltokepernyo.Close(TimeSpan.FromSeconds(2));
            InitializeComponent();
        }

        /// <summary>
        /// <para>Letrehozza a DataContextet, mely az objektum-relacios modellt reprezentalja</para>
        /// <para>Ellenorzi, hogy a felhasznalok tablaban van-e a megadott felhasznalonevvel es jelszoval rendelkezo felhasznalo.</para>
        /// <para>Amennyiben van (mivel a felhasznalo nev egyedisege miatt csak egy lehet), visszaadja</para>
        /// <para>Ha null, azaz nincs, hibat ad!</para>
        /// <para>Ha a felhasznalo joga adminisztrator, akkor beengedi az adminisztratori feluletre</para>
        /// <para>Ha felhasznalo, akkor a felhasznaloi feluletre jut</para>
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonBelepes_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();

                var felhasznaloJelszo = (from Felhasznalos in adatbazis.Felhasznalos
                                        where
                                        Felhasznalos.FelhNev == textBoxFelhNev.Text
                                        select Felhasznalos.Jelszo).Single();

                var jelszoHashEgyezik = BCrypt.Net.BCrypt.EnhancedVerify(passwordBoxJelszo.Password, felhasznaloJelszo);
                var felhasznaloEllenorzese = adatbazis.Felhasznalos.FirstOrDefault(f => f.FelhNev.Equals(textBoxFelhNev.Text) &&
                                                                                        jelszoHashEgyezik == true);
                //Felhasznalo joganak ellenorzese

                if (felhasznaloEllenorzese == null)
                {
                    MessageBox.Show("A felhasznalo nem talalhato!", "A felhasznalo nem talalhato!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    if (felhasznaloEllenorzese.Jog.Nev == "Adminisztrator")
                    {
                        KonyvtarFoablak konyvesBoltAdmin = new KonyvtarFoablak(felhasznaloEllenorzese.ID);
                        konyvesBoltAdmin.Show();
                        this.Close();
                    }
                    else if (felhasznaloEllenorzese.Jog.Nev == "Felhasznalo")
                    {
                        KonyvesboltFelhasznaloFoablak konyvesboltFelh = new KonyvesboltFelhasznaloFoablak(felhasznaloEllenorzese.ID);
                        konyvesboltFelh.Show();
                        this.Close();
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Varatlan hiba tortent!", "Varatlan hiba tortnt!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// <para>Peldanyositom a regisztracios formot, majd megnyitom, a jelenlegit pedig bezarom</para>
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonRegisztracio_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltRegisztracio konyvesboltRegisztracio = new KonyvesboltRegisztracio();
            konyvesboltRegisztracio.Show();
            this.Close();
        }

        private void buttonElfelejtettJelszo_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltElfelejtettJelszo konyvesboltElfelejtettJelszo = new KonyvesboltElfelejtettJelszo();
            konyvesboltElfelejtettJelszo.Show();
            this.Close();
        }
    }
}
