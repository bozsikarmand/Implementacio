﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Szakdolgozat_Implementacio_BozsikArmandViktor
{
    /// <summary>
    /// Interaction logic for KonyvesboltFelhasznaloAjanlottKonyvek.xaml
    /// </summary>
    public partial class KonyvesboltFelhasznaloAjanlottKonyvek : Window
    {
        private int ID;
        public KonyvesboltFelhasznaloAjanlottKonyvek(int ID)
        {
            this.ID = ID;
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var ajanlottKonyvek = (from t1
                                   in adatbazis.Konyvs
                                   where
                                        (from t2
                                        in adatbazis.FelhasznaloKonyvs
                                         where
                                              (from t3
                                               in adatbazis.Felhasznalos
                                               where
                                                    (from t4
                                                     in adatbazis.ErdeklodesiKors
                                                     where t1.ID == t2.KonyvID &&
                                                           t2.FelhasznaloID == ID &&
                                                           t3.ErdeklodesiKorID == t4.ID
                                                     select new
                                                     {
                                                         t4
                                                     }).Single() != null
                                               select new
                                               {
                                                   t3
                                               }).Single() != null
                                         select new
                                         {
                                             t2
                                         }).Single() == null
                                   select new
                                   {
                                       t1.ISBN,
                                       t1.Cim,
                                       t1.Ar,
                                       t1.Kiado
                                   }).Take(10);

            dataGridAjanlottKonyvek.ItemsSource = ajanlottKonyvek;
        }

        private void menuItemFelhasznaloiAdatok_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltFelhasznaloAdatai konyvesboltFelhasznaloAdatai = new KonyvesboltFelhasznaloAdatai(ID);
            konyvesboltFelhasznaloAdatai.Show();
            this.Close();
        }

        private void menuItemKapcsolatfelvetel_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltFelhasznaloKapcsolatfelvetel konyvesboltFelhasznaloKapcsolatfelvetel = new KonyvesboltFelhasznaloKapcsolatfelvetel(ID);
            konyvesboltFelhasznaloKapcsolatfelvetel.Show();
            this.Close();
        }

        private void buttonVisszaFelhasznaloFooldalra_Click(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var felhasznaloID = (from ft
                                 in adatbazis.Felhasznalos
                                 where ft.ID == ID
                                 select ft.ID).Single();

            var felhasznaloJog = (from ft
                                  in adatbazis.Felhasznalos
                                  where ft.ID == ID
                                  select ft.Jog.Nev).Single();

            if (felhasznaloJog.Equals("Adminisztrator"))
            {
                KonyvtarFoablak konyvesboltAdminisztratorFoablak = new KonyvtarFoablak(felhasznaloID);
                konyvesboltAdminisztratorFoablak.Show();
                this.Close();
            }
            if (felhasznaloJog.Equals("Felhasznalo"))
            {
                KonyvesboltFelhasznaloFoablak konyvesboltFelhasznaloFoablak = new KonyvesboltFelhasznaloFoablak(felhasznaloID);
                konyvesboltFelhasznaloFoablak.Show();
                this.Close();
            }
        }
    }
}
