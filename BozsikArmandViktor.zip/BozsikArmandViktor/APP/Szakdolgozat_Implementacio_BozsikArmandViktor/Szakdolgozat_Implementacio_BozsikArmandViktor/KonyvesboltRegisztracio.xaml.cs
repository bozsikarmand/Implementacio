﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Szakdolgozat_Implementacio_BozsikArmandViktor
{
    /// <summary>
    /// Interaction logic for KonyvesboltRegisztracio.xaml
    /// </summary>
    public partial class KonyvesboltRegisztracio : Window
    {
        public KonyvesboltRegisztracio()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Visszalepes a fooldalra
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonVisszaAFooldalra_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        int erdeklodesiKorID = 0;
        List<CheckBox> erdeklodesiKorCB = new List<CheckBox>();
        Random random = new Random();

        private void buttonFelhasznaloLetrehozasa_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
                bool helyesAJelszo = true;
                var felhasznaloiNev = (from f
                                       in adatbazis.Felhasznalos
                                       where f.FelhNev == textBoxFelhNev.Text
                                       select f.FelhNev).SingleOrDefault();

                bool egyezikAFelhasznaloiNev = false;
                bool kisbetusFelhasznaloiNev = true;
                bool joAFelhNevHossza = true;
                bool hazszamHelyes = true;

                if (passwordBoxJelszo.Password != passwordBoxJelszoMegint.Password)
                {
                    helyesAJelszo = false;
                    MessageBox.Show("A megadott jelszavak nem egyeznek!", "A jelszavak nem megfeleloek!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                if (passwordBoxJelszo.Password.Length < 8)
                {
                    helyesAJelszo = false;
                    MessageBox.Show("A megadott uj jelszo kevesebb mint 8 karakter!", "Az uj jelszo nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                if (passwordBoxJelszoMegint.Password.Length < 8)
                {
                    helyesAJelszo = false;
                    MessageBox.Show("A megadott uj jelszo megerositese nem sikeres, mivel kevesebb mint 8 karakter!", "Az uj jelszo megerositese nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                if (!passwordBoxJelszo.Password.Any(char.IsUpper))
                {
                    helyesAJelszo = false;
                    MessageBox.Show("A megadott uj jelszo nem tartalmaz nagybetut! (pl. A, B, C, D, E, F, G, H)", "Az uj jelszo megerositese nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                if (!passwordBoxJelszo.Password.Any(char.IsDigit))
                {
                    helyesAJelszo = false;
                    MessageBox.Show("A megadott uj jelszo nem tartalmaz szamot! (pl. 1, 2, 3, 4, 5, 6, 7, 8)", "Az uj jelszo megerositese nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                if (!textBoxFelhNev.Text.All(char.IsLower))
                {
                    kisbetusFelhasznaloiNev = false;
                    MessageBox.Show("A megadott felhasznalonev nagybetut tartalmaz! (pl. A, B, C, D, E, F, G, H)", "A valasztott felhasznaloi nev nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                if (textBoxFelhNev.Text.Length < 3)
                {
                    joAFelhNevHossza = false;
                    MessageBox.Show("A megadott felhasznaloi nev rovidebb mint 3 karakter!", "A valasztott felhasznaloi nev nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                if (!textBoxHazszam.Text.All(char.IsDigit))
                {
                    hazszamHelyes = false;
                    MessageBox.Show("A megadott hazszam nem megengedett formatumu!", "A megadott hazszam nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                if (felhasznaloiNev == null)
                {
                    if (kisbetusFelhasznaloiNev == false || joAFelhNevHossza == false)
                    {
                        textBoxFelhNev.Text = "";
                    }
                    if (hazszamHelyes == false)
                    {
                        textBoxHazszam.Text = "";
                    }
                    if (helyesAJelszo == false)
                    {
                        passwordBoxJelszo.Password = "";
                        passwordBoxJelszoMegint.Password = "";
                    }
                    else
                    {
                        egyezikAFelhasznaloiNev = false;

                        if (helyesAJelszo == false)
                        {
                            passwordBoxJelszo.Password = "";
                            passwordBoxJelszoMegint.Password = "";
                        }
                        else
                        {
                            try
                            {
                                Felhasznalo felhasznalo = new Felhasznalo();
                                //var felhasznalok = from f in adatbazis.Felhasznalos select f;

                                felhasznalo.Vezeteknev = textBoxVezeteknev.Text;
                                felhasznalo.Keresztnev = textBoxKeresztnev.Text;
                                felhasznalo.Utonev = textBoxUtonev.Text;
                                felhasznalo.FelhNev = textBoxFelhNev.Text;
                                felhasznalo.SzulDatum = DateTime.ParseExact(dateTimePickerSzulDatum.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture); // !
                                felhasznalo.Email = maskedTextBoxEmail.Text;
                                felhasznalo.Tel = textBoxTel.Text;
                                //felhasznalo.Hirlevel = Convert.ToBoolean(textBoxHirlevel.Text); // !
                                felhasznalo.Hirlevel = checkBoxHirlevel.IsChecked.Value;
                                felhasznalo.Jelszo = BCrypt.Net.BCrypt.EnhancedHashPassword(passwordBoxJelszo.Password);
                                // yyyy-mm-dd
                                felhasznalo.Nevnap = DateTime.ParseExact(dateTimePickerNevnap.Text, "MM-dd", CultureInfo.InvariantCulture); // !
                                felhasznalo.Varos = textBoxVaros.Text;
                                felhasznalo.Utca = textBoxUtca.Text;
                                felhasznalo.Hazszam = Convert.ToInt32(textBoxHazszam.Text);
                                //felhasznalo.ErdeklodesiKorID = Convert.ToInt32(textBoxErdeklodesiKorID.Text);

                                felhasznalo.ErdeklodesiKorID = erdeklodesiKorID;

                                felhasznalo.JogID = 2;

                                adatbazis.Felhasznalos.InsertOnSubmit(felhasznalo);
                                adatbazis.SubmitChanges();
                                MessageBox.Show("On sikeresen regisztralt rendszerunkben! Automatikusan visszairanyitjuk a kezdo oldalra ahol belephet az adataival!");

                                MainWindow mainWindow = new MainWindow();
                                mainWindow.Show();
                                this.Close();
                            }
                            catch
                            {
                                MessageBox.Show("A regisztracios kerelmevel kapcsolatban hibakat eszleltunk! Kerem tekintse at es javitsa adatait, majd probalja ujra az urlap elkuldeset!", "Tajekoztatas", MessageBoxButton.OK, MessageBoxImage.Stop);
                            }
                        }
                    }
                }
                else if (felhasznaloiNev.Equals(textBoxFelhNev.Text))
                {
                    egyezikAFelhasznaloiNev = true;
                    if (egyezikAFelhasznaloiNev)
                    {
                        MessageBox.Show("A kivant felhasznalonevvel mar regisztraltak rendszerunkbe!", "A valasztott felhasznalonev nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
                        textBoxFelhNev.Text = "";
                    }
                    if (helyesAJelszo == false)
                    {
                        passwordBoxJelszo.Password = "";
                        passwordBoxJelszoMegint.Password = "";
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Helytelen adat!", "HIBA!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void textBoxVezeteknev_GotFocus(object sender, RoutedEventArgs e)
        {
        }

        private void textBoxVezeteknev_LostFocus(object sender, RoutedEventArgs e)
        {
        }

        private void checkBoxKategoriaIsmeretterjeszto_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[0].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 1;
            }
        }

        private void checkBoxKategoriaIsmeretterjeszto_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;
            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }

        private void checkBoxKategoriaSzamitastechnika_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[1].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 2;
            }
        }

        private void checkBoxKategoriaSzamitastechnika_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;

            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorCB.Add(checkBoxKategoriaIsmeretterjeszto);
            erdeklodesiKorCB.Add(checkBoxKategoriaSzamitastechnika);
            erdeklodesiKorCB.Add(checkBoxKategoriaIrodalom);
            erdeklodesiKorCB.Add(checkBoxKategoriaTortenelemEsEmber);
            erdeklodesiKorCB.Add(checkBoxKategoriaKlasszikusTudomanyok);
            erdeklodesiKorCB.Add(checkBoxKategoriaOktatas);

            if (checkBoxKategoriaIsmeretterjeszto.IsChecked == false)
            {
                checkBoxKategoriaIsmeretterjeszto.IsChecked = true;
            }
        }

        private void checkBoxKategoriaIrodalom_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[2].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 3;
            }
        }

        private void checkBoxKategoriaIrodalom_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;

            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }

        private void checkBoxKategoriaTortenelemEsEmber_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[3].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 4;
            }
        }

        private void checkBoxKategoriaTortenelemEsEmber_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;

            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }

        private void checkBoxKategoriaKlasszikusTudomanyok_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[4].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 5;
            }
        }

        private void checkBoxKategoriaKlasszikusTudomanyok_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;

            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }

        private void checkBoxKategoriaOktatas_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[5].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 6;
            }
        }

        private void checkBoxKategoriaOktatas_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;

            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }
    }
}
