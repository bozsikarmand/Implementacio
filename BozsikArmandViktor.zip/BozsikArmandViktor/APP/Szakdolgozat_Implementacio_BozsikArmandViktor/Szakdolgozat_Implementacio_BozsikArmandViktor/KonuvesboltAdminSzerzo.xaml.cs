﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Szakdolgozat_Implementacio_BozsikArmandViktor
{
    /// <summary>
    /// Interaction logic for KonuvesboltAdminSzerzo.xaml
    /// </summary>
    public partial class KonuvesboltAdminSzerzo : Window
    {
        private int ID;
        public KonuvesboltAdminSzerzo(int ID)
        {
            this.ID = ID;
            InitializeComponent();
            DataGridFeltoltese();
        }

        /// <summary>
        /// Letrehozom a DataContextet, mely az objektum-relacios modellt reprezentalja
        /// Az osszes szerzo lekerdezesre kerul
        /// A dataGrid forrasa a lekerdezes eredmenytablaja lesz
        /// </summary>
        private void DataGridFeltoltese()
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var szerzo = (from sz in adatbazis.Szerzos select sz);
            dataGridSzerzo.ItemsSource = szerzo;
        }

        /// <summary>
        /// Letrehozom a DataContextet
        /// Eltarolom a felhasznalo altal kivalasztott sort
        /// A sorbol kivalasztom az ID-t
        /// Az adatbazis szerzo tablajabol kivalasztom azokat a rekordokat, ahol az ID es a sor ID-ja egyezik.
        /// A szerzo objektumnak ertekul adom a dataGrid megfelelo oszlopait
        /// Rogzitem a valtoztatasokat a kivalasztott elemen
        /// Visszajelzek a felhasznalonak
        /// Frissitem a dataGrid-et
        /// Ha hiba tortenik, lekezelem
        /// </summary>
        private void DataGridFrissitese()
        {
            try
            {
                AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
                Szerzo szerzoSora = dataGridSzerzo.SelectedItem as Szerzo;

                var id = szerzoSora.ID;
                Szerzo szerzo = (from sz in adatbazis.Szerzos
                                           where sz.ID == szerzoSora.ID
                                           select sz).Single();
                szerzo.KonyvISBN = szerzoSora.KonyvISBN;
                szerzo.Szerzonev = szerzoSora.Szerzonev;                

                adatbazis.SubmitChanges();
                MessageBox.Show("A szerzo sikeresen frissitve!");
                DataGridFeltoltese();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Helytelen adat!", "HIBA!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Letrehozom a DataContextet
        /// Eltarolom a felhasznalo altal kivalasztott sort
        /// A sorbol kivalasztom az ID-t
        /// Az adatbazis szerzo tablajabol kivalasztom azokat a rekordokat, ahol az ID es a sor ID-ja egyezik.
        /// Torlom a kivalasztott elemet
        /// Elkuldom a valtozasokat az adatbazis szerver fele
        /// Visszajelzek a felhasznalonak
        /// Frissitem a dataGrid-et
        /// Ha hiba tortenik, lekezelem
        /// </summary>
        private void DataGridElemTorlese()
        {
            try
            {
                AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
                Szerzo szerzoSora = dataGridSzerzo.SelectedItem as Szerzo;

                var szerzo = (from sz in adatbazis.Szerzos
                                   where sz.ID == szerzoSora.ID
                                   select sz).Single();
                adatbazis.Szerzos.DeleteOnSubmit(szerzo);
                adatbazis.SubmitChanges();
                MessageBox.Show("A szerzo sikeresen torolve!");
                DataGridFeltoltese();
            }
            catch (Exception ex)
            {
                MessageBox.Show("HIBA!", "HIBA!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// dataGrid frissitese modositas utan
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonModositas_Click(object sender, RoutedEventArgs e)
        {
            DataGridFrissitese();
        }

        /// <summary>
        /// dataGrid elem torlese
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonTorles_Click(object sender, RoutedEventArgs e)
        {
            DataGridElemTorlese();
        }

        /// <summary>
        /// Letrehozom a DataContext-et
        /// Letrehozok egy uj szerzo objektumot
        /// Ertekul adom az objektumnak a beviteli mezok erteket
        /// Az uj rekordot beillesztem az adatbazisba
        /// Elkuldom a valtozasokat az adatbazis szerver fele
        /// Visszajelzek a felhasznalonak
        /// Frissitem a dataGrid-et
        /// Ha hiba tortenik, lekezelem
        /// </summary>
        private void DataGridElemHozzaadasa()
        {
            try
            {
                AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
                Szerzo szerzo = new Szerzo();

                szerzo.KonyvISBN = textBoxKonyvISBN.Text;
                szerzo.Szerzonev = textBoxSzerzonev.Text;

                adatbazis.Szerzos.InsertOnSubmit(szerzo);
                adatbazis.SubmitChanges();
                MessageBox.Show("A szerzo sikeresen hozzaadva!");
                DataGridFeltoltese();
            }
            catch (Exception ex)
            {
                MessageBox.Show("HIBA!", "HIBA!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// dataGrid elem hozzadasa
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonHozzaadas_Click(object sender, RoutedEventArgs e)
        {
            DataGridElemHozzaadasa();
        }

        private void menuItemFelhasznalo_Click(object sender, RoutedEventArgs e)
        {
            KonuvesboltAdminFelhasznalo konuvesboltAdminFelhasznalo = new KonuvesboltAdminFelhasznalo(ID);
            konuvesboltAdminFelhasznalo.Show();
            this.Close();
        }

        private void menuItemKonyv_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltAdminKonyv konyvesboltAdminKonyv = new KonyvesboltAdminKonyv(ID);
            konyvesboltAdminKonyv.Show();
            this.Close();
        }

        private void buttonVisszaAdminFooldalra_Click(object sender, RoutedEventArgs e)
        {
            KonyvtarFoablak konyvesbooltAdminFoablak = new KonyvtarFoablak(ID);
            konyvesbooltAdminFoablak.Show();
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dataGridSzerzo.CanUserAddRows = false;
        }
    }
}
