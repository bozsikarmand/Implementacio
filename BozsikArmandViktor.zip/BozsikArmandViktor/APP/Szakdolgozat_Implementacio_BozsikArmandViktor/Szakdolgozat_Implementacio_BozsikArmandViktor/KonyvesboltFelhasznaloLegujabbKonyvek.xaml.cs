﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Szakdolgozat_Implementacio_BozsikArmandViktor
{
    /// <summary>
    /// Interaction logic for KonyvesboltFelhasznaloLegujabbKonyvek.xaml
    /// </summary>
    public partial class KonyvesboltFelhasznaloLegujabbKonyvek : Window
    {
        private int ID;
        public KonyvesboltFelhasznaloLegujabbKonyvek(int ID)
        {
            this.ID = ID;
            InitializeComponent();
        }

        private void menuItemFelhasznaloiAdatok_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltFelhasznaloAdatai konyvesboltFelhasznaloAdatai = new KonyvesboltFelhasznaloAdatai(ID);
            konyvesboltFelhasznaloAdatai.Show();
            this.Close();
        }

        private void menuItemKapcsolatfelvetel_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltFelhasznaloKapcsolatfelvetel konyvesboltFelhasznaloKapcsolatfelvetel = new KonyvesboltFelhasznaloKapcsolatfelvetel(ID);
            konyvesboltFelhasznaloKapcsolatfelvetel.Show();
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var legujabbKonyvek = (from l in adatbazis.Konyvs orderby l.ID descending select new { l.ISBN, l.Cim, l.Ar } ).Take(10);

            dataGridLegujabbKonyvek.ItemsSource = legujabbKonyvek;
        }

        private void buttonVisszaAFelhasznaloiFooldalra_Click(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var felhasznaloID = (from ft
                                 in adatbazis.Felhasznalos
                                 where ft.ID == ID
                                 select ft.ID).Single();

            var felhasznaloJog = (from ft
                                  in adatbazis.Felhasznalos
                                  where ft.ID == ID
                                  select ft.Jog.Nev).Single();

            if (felhasznaloJog.Equals("Adminisztrator"))
            {
                KonyvtarFoablak konyvesboltAdminisztratorFoablak = new KonyvtarFoablak(felhasznaloID);
                konyvesboltAdminisztratorFoablak.Show();
                this.Close();
            }
            if (felhasznaloJog.Equals("Felhasznalo"))
            {
                KonyvesboltFelhasznaloFoablak konyvesboltFelhasznaloFoablak = new KonyvesboltFelhasznaloFoablak(felhasznaloID);
                konyvesboltFelhasznaloFoablak.Show();
                this.Close();
            }
        }
    }
}
