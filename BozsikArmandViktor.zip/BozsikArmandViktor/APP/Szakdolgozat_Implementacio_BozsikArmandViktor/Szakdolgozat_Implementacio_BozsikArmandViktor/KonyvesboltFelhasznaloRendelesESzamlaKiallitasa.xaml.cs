﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Szakdolgozat_Implementacio_BozsikArmandViktor
{
    /// <summary>
    /// Interaction logic for KonyvesboltFelhasznaloRendelesOsszesites.xaml
    /// </summary>
    public partial class KonyvesboltFelhasznaloRendelesOsszesites : Window
    {
        private int ID;
        private Konyv konyvSora;
        public KonyvesboltFelhasznaloRendelesOsszesites(int ID, Konyv konyvSora)
        {
            this.ID = ID;
            this.konyvSora = konyvSora;
            InitializeComponent();
            buttonESzamla.IsEnabled = false;
        }

        private void checkboxEllenorzese()
        {
            if (checkBoxAdatkezelesiTajekoztato.IsChecked == true && 
                checkBoxASZF.IsChecked == true)
            {
                buttonESzamla.IsEnabled = true;
            }
        }

        private void buttonESzamla_Click(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();

            var konyv = (from k in adatbazis.Konyvs
                         where k.ID == konyvSora.ID
                         select k).Single();

            

            ////////////////////////////////////////////////////////////////////////
            Szamla szamla = new Szamla();

            #region AdatbazisAdatok
            var jelenlegiVevo = (from v in adatbazis.Felhasznalos
                                 where v.ID == ID
                                 select v).First();

            Konyv rendelesSora = dataGridSzamlaOsszesito.Items[0] as Konyv;

            var jelenlegVasaroltKonyv = (from k in adatbazis.Konyvs
                                         where k.ID == rendelesSora.ID
                                         select k).Single();

            var jelenlegiSzamla = (from sz in adatbazis.Szamlas
                                   orderby sz.ID descending
                                   select sz).First();
            #endregion

            szamla.FelhasznaloID = jelenlegiVevo.ID;
            szamla.KonyvID = jelenlegVasaroltKonyv.ID;
            szamla.Tartalom = "FIZETVE";

            adatbazis.Szamlas.InsertOnSubmit(szamla);

            ////////////////////////

            SaveFileDialog szamlaMenteseDialog = new SaveFileDialog();
            szamlaMenteseDialog.Filter = "PDF|*.pdf";
            szamlaMenteseDialog.Title = "Kerem adja meg, hogy hova, illetve milyen neven mentsuk el a a PDF e-szamlat";

            bool? eredmeny = szamlaMenteseDialog.ShowDialog();

            if (eredmeny == true)
            {
                try
                {
                    Document pdfSzamla = new Document(iTextSharp.text.PageSize.A4, 0, 0, 15, 15);
                    PdfWriter kimenet = PdfWriter.GetInstance(pdfSzamla, new FileStream(szamlaMenteseDialog.FileName, FileMode.Create));

                    pdfSzamla.Open();

                    #region SzovegekEsAdatok
                    Chunk kiallitoCimSzoveg = new Chunk("Kiallito:", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk kiallitoCimAdat = new Chunk("Bozsik Armand Konyvesboltja\n1234 Budapest\nTeszt utca 1.\nAdoszam: 12345678-1-12\nSzamlaszam:\nTeszt Bank\n12345678-12345678-12345678", FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk vevoCimSzoveg = new Chunk("Vevo:", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk vevoCimAdat = new Chunk("Vevokod: " + jelenlegiVevo.ID + "\n" +
                                                  String.Concat(jelenlegiVevo.Vezeteknev, " ", jelenlegiVevo.Keresztnev) + "\n" +
                                                  jelenlegiVevo.Varos + "\n" + jelenlegiVevo.Utca + " " + jelenlegiVevo.Hazszam, FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk szamlazasiCimSzoveg = new Chunk("Szamlazasi cim:", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk szamlazasiCimAdat = new Chunk("L" + jelenlegiVevo.ID + "\n" +
                                                        String.Concat(jelenlegiVevo.Vezeteknev, " ",
                                                                      jelenlegiVevo.Keresztnev) + "\n" +
                                                                      jelenlegiVevo.Varos + "\n" +
                                                                      jelenlegiVevo.Utca + " " +
                                                                      jelenlegiVevo.Hazszam, FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk szamlaCimSzoveg = new Chunk("Szamla", FontFactory.GetFont("Times New Roman", 22, Font.BOLD, BaseColor.BLACK));

                    Chunk szamlaAzonositoSzoveg = new Chunk(String.Concat("Keszult 1. elektronikus peldanyban", "\n", "Szamla azonosito: " + (jelenlegiSzamla.ID + 1), "\n", "Megrendeles azonosito: " + (jelenlegiSzamla.ID + 1)), FontFactory.GetFont("Times New Roman", 8, Font.BOLD, BaseColor.BLACK));

                    Chunk teljesitesDatumaSzoveg = new Chunk("Teljesites datuma:", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk teljesitesDatumaAdat = new Chunk(DateTime.Now.ToString("yyyy-MM-dd"), FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk szamviteliTeljesitesSzoveg = new Chunk("Szamviteli teljesites:", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk szamviteliTeljesitesAdat = new Chunk("", FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk szamlaKelteSzoveg = new Chunk("Szamla kelte:", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk szamlaKelteAdat = new Chunk(DateTime.Now.ToString("yyyy-MM-dd"), FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk fizetesiHataridoSzoveg = new Chunk("Fizetesi hatarido:", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk fizetesHataridoAdat = new Chunk(DateTime.Now.ToString("yyyy-MM-dd"), FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk fizetesiModSzoveg = new Chunk("Fizetesi mod:", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk fizetesModAdat = new Chunk("Asztali kliensbol", FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk penznemSzoveg = new Chunk("Penznem: HUF", FontFactory.GetFont("Times New Roman", 16, Font.BOLD, BaseColor.BLACK));

                    int a = 1;
                    Chunk mennyisegSzoveg = new Chunk("Menny.", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk mennyisegAdat = new Chunk("1", FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk isbnSzoveg = new Chunk("ISBN", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk isbnAdat = new Chunk(jelenlegVasaroltKonyv.ISBN.ToString(), FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk idSzoveg = new Chunk("ID", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk idAdat = new Chunk(jelenlegVasaroltKonyv.ID.ToString(), FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk egysegArSzoveg = new Chunk("Egys. ar", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk egysegArAdat = new Chunk(jelenlegVasaroltKonyv.Ar.ToString(), FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk nettoErtSzoveg = new Chunk("Netto ert.", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk nettoErtAdat = new Chunk((jelenlegVasaroltKonyv.Ar * 0.73).ToString(), FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk afaSzazalekSzoveg = new Chunk("Afa %", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk afaSzazalekAdat = new Chunk("27%", FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk afaErtSzoveg = new Chunk("Afa ert.", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk afaErtAdat = new Chunk((jelenlegVasaroltKonyv.Ar * 0.27).ToString(), FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk bruttoErtSzoveg = new Chunk("Brutto ert.", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk bruttoErtAdat = new Chunk((jelenlegVasaroltKonyv.Ar).ToString(), FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk mennyisegOsszesenSzoveg = new Chunk("Mennyiseg osszesen:", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk mennyisegOsszesenAdat = new Chunk("1", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));

                    Chunk afaKulcsSzoveg = new Chunk("Afa kulcs:", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk afaKulcsAdat = new Chunk("27%", FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk afaAlapSzoveg = new Chunk("Afa alap:", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk afaAlapAdat = new Chunk((jelenlegVasaroltKonyv.Ar * 0.73).ToString(), FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk afaErtekSzoveg = new Chunk("Afa ertek:", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk afaErtekAdat = new Chunk((jelenlegVasaroltKonyv.Ar * 0.27).ToString(), FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk afaErtekOsszesenSzoveg = new Chunk("Afa ertek osszesen:", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk afaErtekOsszesenAdat = new Chunk((jelenlegVasaroltKonyv.Ar * 0.27).ToString() + " HUF", FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk bizonylatNettoErtekSzoveg = new Chunk("Bizonylat netto ertek:", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk bizonylatNettoErtekAdat = new Chunk((jelenlegVasaroltKonyv.Ar * 0.73).ToString() + " HUF", FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk bizonylatVegosszegSzoveg = new Chunk("Vegosszeg:", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk bizonylatVegosszegAdat = new Chunk((jelenlegVasaroltKonyv.Ar).ToString() + " HUF", FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk szamlaVegosszegSzoveg = new Chunk("A szamla vegosszege:", FontFactory.GetFont("Times New Roman", 12, Font.BOLD, BaseColor.BLACK));
                    Chunk szamlaVegosszegAdat = new Chunk((jelenlegVasaroltKonyv.Ar).ToString() + " HUF", FontFactory.GetFont("Times New Roman", 12, Font.NORMAL, BaseColor.BLACK));

                    Chunk szamlaFizetve = new Chunk("FIZETVE", FontFactory.GetFont("Consolas", 72, Font.NORMAL, BaseColor.GRAY));
                    #endregion

                    #region FelsoTablaCimek
                    PdfPTable felsoTablazatCimek = new PdfPTable(2);
                    PdfPCell kiallitoCim = new PdfPCell(new Phrase(kiallitoCimSzoveg));
                    felsoTablazatCimek.AddCell(kiallitoCim);
                    PdfPCell vevoCim = new PdfPCell(new Phrase(vevoCimSzoveg));
                    felsoTablazatCimek.AddCell(vevoCim);
                    pdfSzamla.Add(felsoTablazatCimek);
                    #endregion

                    #region FelsoTablazat
                    PdfPTable felsoTablazat = new PdfPTable(2);
                    PdfPCell kiallito = new PdfPCell(new Phrase(kiallitoCimAdat));
                    kiallito.Rowspan = 3;
                    felsoTablazat.AddCell(kiallito);
                    PdfPCell vevo = new PdfPCell(new Phrase(vevoCimAdat));
                    felsoTablazat.AddCell(vevo);
                    PdfPCell szamlazasiCim = new PdfPCell(new Phrase(szamlazasiCimSzoveg));
                    felsoTablazat.AddCell(szamlazasiCim);
                    PdfPCell szamlazasiCimAdatCella = new PdfPCell(new Phrase(szamlazasiCimAdat));
                    felsoTablazat.AddCell(szamlazasiCimAdatCella);
                    pdfSzamla.Add(felsoTablazat);
                    pdfSzamla.Add(new iTextSharp.text.Paragraph(" "));
                    #endregion

                    #region CimEsAttributumokBeallitasa
                    PdfPTable cimTablazat = new PdfPTable(3);
                    PdfPCell uresSzamlaCim = new PdfPCell(new Phrase(""));
                    uresSzamlaCim.Border = 0;
                    cimTablazat.AddCell(uresSzamlaCim);

                    PdfPCell szamlaCim = new PdfPCell(new Phrase(szamlaCimSzoveg));
                    szamlaCim.Border = 0;
                    szamlaCim.HorizontalAlignment = Element.ALIGN_CENTER;
                    szamlaCim.VerticalAlignment = Element.ALIGN_MIDDLE;
                    cimTablazat.AddCell(szamlaCim);

                    PdfPCell szamlaAzonosito = new PdfPCell(new Phrase(szamlaAzonositoSzoveg));
                    szamlaAzonosito.Border = 0;
                    cimTablazat.AddCell(szamlaAzonosito);

                    pdfSzamla.Add(cimTablazat);
                    #endregion

                    #region SzamlaFejlec
                    pdfSzamla.Add(new iTextSharp.text.Paragraph(" "));
                    PdfPTable szamlaAdatTablazatCimek = new PdfPTable(5);
                    PdfPCell teljesitesDatumaSz = new PdfPCell(new Phrase(teljesitesDatumaSzoveg));
                    szamlaAdatTablazatCimek.AddCell(teljesitesDatumaSz);
                    PdfPCell szamviteliTeljSz = new PdfPCell(new Phrase(szamviteliTeljesitesSzoveg));
                    szamlaAdatTablazatCimek.AddCell(szamviteliTeljSz);
                    PdfPCell szamlaKelteSz = new PdfPCell(new Phrase(szamlaKelteSzoveg));
                    szamlaAdatTablazatCimek.AddCell(szamlaKelteSz);
                    PdfPCell fizetesiHataridoSz = new PdfPCell(new Phrase(fizetesiHataridoSzoveg));
                    szamlaAdatTablazatCimek.AddCell(fizetesiHataridoSz);
                    PdfPCell fizetesiModSz = new PdfPCell(new Phrase(fizetesiModSzoveg));
                    szamlaAdatTablazatCimek.AddCell(fizetesiModSz);
                    pdfSzamla.Add(szamlaAdatTablazatCimek);
                    #endregion

                    #region SzamlaFejlecAdat
                    PdfPTable szamlaAdatTablazat = new PdfPTable(5);
                    PdfPCell teljesitesDatumaA = new PdfPCell(new Phrase(teljesitesDatumaAdat));
                    szamlaAdatTablazat.AddCell(teljesitesDatumaA);
                    PdfPCell szamviteliTeljA = new PdfPCell(new Phrase(szamviteliTeljesitesAdat));
                    szamlaAdatTablazat.AddCell(szamviteliTeljA);
                    PdfPCell szamlaKelteA = new PdfPCell(new Phrase(szamlaKelteAdat));
                    szamlaAdatTablazat.AddCell(szamlaKelteA);
                    PdfPCell fizetesiHataridoA = new PdfPCell(new Phrase(fizetesHataridoAdat));
                    szamlaAdatTablazat.AddCell(fizetesiHataridoA);
                    PdfPCell fizetesiModA = new PdfPCell(new Phrase(fizetesModAdat));
                    szamlaAdatTablazat.AddCell(fizetesiModA);
                    pdfSzamla.Add(szamlaAdatTablazat);
                    #endregion

                    #region Penznem
                    PdfPTable penznemTablazat = new PdfPTable(1);
                    PdfPCell penznemSz = new PdfPCell(new Phrase(penznemSzoveg));
                    penznemSz.Border = 0;
                    penznemSz.HorizontalAlignment = Element.ALIGN_RIGHT;
                    penznemSz.VerticalAlignment = Element.ALIGN_MIDDLE;
                    penznemTablazat.AddCell(penznemSz);
                    pdfSzamla.Add(penznemTablazat);
                    pdfSzamla.Add(new iTextSharp.text.Paragraph(" "));
                    pdfSzamla.Add(new iTextSharp.text.Paragraph(" "));
                    pdfSzamla.Add(new iTextSharp.text.Paragraph(" "));
                    pdfSzamla.Add(new iTextSharp.text.Paragraph(" "));
                    #endregion

                    #region MegvasaroltTetelekTablazatSzoveg
                    PdfPTable megvasaroltTetelekTablazatSzoveg = new PdfPTable(8);
                    PdfPCell mennyisegSz = new PdfPCell(new Phrase(mennyisegSzoveg));
                    megvasaroltTetelekTablazatSzoveg.AddCell(mennyisegSz);
                    PdfPCell isbnSz = new PdfPCell(new Phrase(isbnSzoveg));
                    megvasaroltTetelekTablazatSzoveg.AddCell(isbnSz);
                    PdfPCell idSz = new PdfPCell(new Phrase(idSzoveg));
                    megvasaroltTetelekTablazatSzoveg.AddCell(idSz);
                    PdfPCell egysegArSz = new PdfPCell(new Phrase(egysegArSzoveg));
                    megvasaroltTetelekTablazatSzoveg.AddCell(egysegArSz);
                    PdfPCell nettoErtSz = new PdfPCell(new Phrase(nettoErtSzoveg));
                    megvasaroltTetelekTablazatSzoveg.AddCell(nettoErtSz);
                    PdfPCell afaSzazalekSz = new PdfPCell(new Phrase(afaSzazalekSzoveg));
                    megvasaroltTetelekTablazatSzoveg.AddCell(afaSzazalekSz);
                    PdfPCell afaErtSz = new PdfPCell(new Phrase(afaErtSzoveg));
                    megvasaroltTetelekTablazatSzoveg.AddCell(afaErtSz);
                    PdfPCell bruttoErtSz = new PdfPCell(new Phrase(bruttoErtSzoveg));
                    megvasaroltTetelekTablazatSzoveg.AddCell(bruttoErtSz);
                    pdfSzamla.Add(megvasaroltTetelekTablazatSzoveg);
                    #endregion

                    #region MegvasaroltTetelekTablazatAdat
                    PdfPTable megvasaroltTetelekTablazatAdat = new PdfPTable(8);
                    PdfPCell mennyisegA = new PdfPCell(new Phrase(mennyisegAdat));
                    megvasaroltTetelekTablazatAdat.AddCell(mennyisegA);
                    PdfPCell isbnA = new PdfPCell(new Phrase(isbnAdat));
                    megvasaroltTetelekTablazatAdat.AddCell(isbnA);
                    PdfPCell idA = new PdfPCell(new Phrase(idAdat));
                    megvasaroltTetelekTablazatAdat.AddCell(idA);
                    PdfPCell egysegArA = new PdfPCell(new Phrase(egysegArAdat));
                    megvasaroltTetelekTablazatAdat.AddCell(egysegArA);
                    PdfPCell nettoErtA = new PdfPCell(new Phrase(nettoErtAdat));
                    megvasaroltTetelekTablazatAdat.AddCell(nettoErtA);
                    PdfPCell afaSzazalekA = new PdfPCell(new Phrase(afaSzazalekAdat));
                    megvasaroltTetelekTablazatAdat.AddCell(afaSzazalekA);
                    PdfPCell afaErtA = new PdfPCell(new Phrase(afaErtAdat));
                    megvasaroltTetelekTablazatAdat.AddCell(afaErtA);
                    PdfPCell bruttoErtA = new PdfPCell(new Phrase(bruttoErtAdat));
                    megvasaroltTetelekTablazatAdat.AddCell(bruttoErtA);
                    pdfSzamla.Add(megvasaroltTetelekTablazatAdat);
                    #endregion

                    #region MennyisegOsszesen
                    PdfPTable mennyisegOsszesenTablazat = new PdfPTable(4);
                    PdfPCell uresMennyisegElso = new PdfPCell(new Phrase(" "));
                    uresMennyisegElso.Border = 0;
                    mennyisegOsszesenTablazat.AddCell(uresMennyisegElso);
                    PdfPCell uresMennyisegMasodik = new PdfPCell(new Phrase(" "));
                    uresMennyisegMasodik.Border = 0;
                    mennyisegOsszesenTablazat.AddCell(uresMennyisegMasodik);
                    PdfPCell mennyisegOsszesenSz = new PdfPCell(new Phrase(mennyisegOsszesenSzoveg));
                    mennyisegOsszesenSz.Border = 0;
                    mennyisegOsszesenSz.HorizontalAlignment = Element.ALIGN_RIGHT;
                    mennyisegOsszesenSz.VerticalAlignment = Element.ALIGN_MIDDLE;
                    mennyisegOsszesenTablazat.AddCell(mennyisegOsszesenSz);

                    PdfPCell mennyisegOsszesenA = new PdfPCell(new Phrase(mennyisegOsszesenAdat));
                    mennyisegOsszesenA.Border = 0;
                    mennyisegOsszesenA.HorizontalAlignment = Element.ALIGN_RIGHT;
                    mennyisegOsszesenA.VerticalAlignment = Element.ALIGN_MIDDLE;
                    mennyisegOsszesenTablazat.AddCell(mennyisegOsszesenA);
                    pdfSzamla.Add(mennyisegOsszesenTablazat);
                    pdfSzamla.Add(new iTextSharp.text.Paragraph(" "));
                    pdfSzamla.Add(new iTextSharp.text.Paragraph(" "));
                    #endregion

                    #region Afa
                    PdfPTable afaTablaSzoveg = new PdfPTable(5);
                    PdfPCell afaUresElso = new PdfPCell(new Phrase(" "));
                    afaUresElso.Border = 0;
                    afaTablaSzoveg.AddCell(afaUresElso);
                    PdfPCell afaUresMasodik = new PdfPCell(new Phrase(" "));
                    afaUresMasodik.Border = 0;
                    afaTablaSzoveg.AddCell(afaUresMasodik);
                    PdfPCell afaKulcsSz = new PdfPCell(new Phrase(afaKulcsSzoveg));
                    afaKulcsSz.HorizontalAlignment = Element.ALIGN_RIGHT;
                    afaKulcsSz.VerticalAlignment = Element.ALIGN_MIDDLE;
                    afaTablaSzoveg.AddCell(afaKulcsSz);
                    PdfPCell afaAlapSz = new PdfPCell(new Phrase(afaAlapSzoveg));
                    afaAlapSz.HorizontalAlignment = Element.ALIGN_RIGHT;
                    afaAlapSz.VerticalAlignment = Element.ALIGN_MIDDLE;
                    afaTablaSzoveg.AddCell(afaAlapSz);
                    PdfPCell afaErtekSz = new PdfPCell(new Phrase(afaErtekSzoveg));
                    afaErtekSz.HorizontalAlignment = Element.ALIGN_RIGHT;
                    afaErtekSz.VerticalAlignment = Element.ALIGN_MIDDLE;
                    afaTablaSzoveg.AddCell(afaErtekSz);
                    pdfSzamla.Add(afaTablaSzoveg);

                    PdfPTable afaTablaAdat = new PdfPTable(5);
                    PdfPCell afaUresElsoA = new PdfPCell(new Phrase(" "));
                    afaUresElsoA.Border = 0;
                    afaTablaAdat.AddCell(afaUresElsoA);
                    PdfPCell afaUresMasodikA = new PdfPCell(new Phrase(" "));
                    afaUresMasodikA.Border = 0;
                    afaTablaAdat.AddCell(afaUresMasodikA);
                    PdfPCell afaKulcsA = new PdfPCell(new Phrase(afaKulcsAdat));
                    afaKulcsA.HorizontalAlignment = Element.ALIGN_RIGHT;
                    afaKulcsA.VerticalAlignment = Element.ALIGN_MIDDLE;
                    afaTablaAdat.AddCell(afaKulcsA);
                    PdfPCell afaAlapA = new PdfPCell(new Phrase(afaAlapAdat));
                    afaAlapA.HorizontalAlignment = Element.ALIGN_RIGHT;
                    afaAlapA.VerticalAlignment = Element.ALIGN_MIDDLE;
                    afaTablaAdat.AddCell(afaAlapA);
                    PdfPCell afaErtekA = new PdfPCell(new Phrase(afaErtekAdat));
                    afaErtekA.HorizontalAlignment = Element.ALIGN_RIGHT;
                    afaErtekA.VerticalAlignment = Element.ALIGN_MIDDLE;
                    afaTablaAdat.AddCell(afaErtekA);
                    pdfSzamla.Add(afaTablaAdat);
                    #endregion

                    #region AfaErtekOsszesen
                    PdfPTable afaErtekTabla = new PdfPTable(5);
                    PdfPCell afaErtekUresElso = new PdfPCell(new Phrase(""));
                    afaErtekUresElso.Border = 0;
                    afaErtekTabla.AddCell(afaErtekUresElso);
                    PdfPCell afaErtekUresMasodik = new PdfPCell(new Phrase(""));
                    afaErtekUresMasodik.Border = 0;
                    afaErtekTabla.AddCell(afaErtekUresMasodik);
                    PdfPCell afaErtekUresHarmadik = new PdfPCell(new Phrase(""));
                    afaErtekUresHarmadik.Border = 0;
                    afaErtekTabla.AddCell(afaErtekUresHarmadik);
                    pdfSzamla.Add(new iTextSharp.text.Paragraph(" "));
                    PdfPCell afaErtekOsszSz = new PdfPCell(new Phrase(afaErtekOsszesenSzoveg));
                    afaErtekTabla.AddCell(afaErtekOsszSz);
                    PdfPCell afaErtekOsszA = new PdfPCell(new Phrase(afaErtekOsszesenAdat));
                    afaErtekTabla.AddCell(afaErtekOsszA);
                    pdfSzamla.Add(afaErtekTabla);
                    #endregion

                    #region BizonylatErtek
                    PdfPTable bizonylatErtekTabla = new PdfPTable(5);
                    PdfPCell bizonylatErtekUresElso = new PdfPCell(new Phrase(""));
                    bizonylatErtekUresElso.Border = 0;
                    bizonylatErtekTabla.AddCell(bizonylatErtekUresElso);
                    PdfPCell bizonylatErtekUresMasodik = new PdfPCell(new Phrase(""));
                    bizonylatErtekUresMasodik.Border = 0;
                    bizonylatErtekTabla.AddCell(bizonylatErtekUresMasodik);
                    PdfPCell bizonylatErtekUresHarmadik = new PdfPCell(new Phrase(""));
                    bizonylatErtekUresHarmadik.Border = 0;
                    bizonylatErtekTabla.AddCell(bizonylatErtekUresHarmadik);
                    PdfPCell bizonylatNettoErtekSz = new PdfPCell(new Phrase(bizonylatNettoErtekSzoveg));
                    bizonylatErtekTabla.AddCell(bizonylatNettoErtekSz);
                    PdfPCell bizonylatNettoErtekA = new PdfPCell(new Phrase(bizonylatNettoErtekAdat));
                    bizonylatErtekTabla.AddCell(bizonylatNettoErtekA);
                    pdfSzamla.Add(bizonylatErtekTabla);
                    pdfSzamla.Add(new iTextSharp.text.Paragraph(" "));
                    #endregion

                    #region BizonylatVegosszeg
                    PdfPTable bizonylatVegosszegTabla = new PdfPTable(5);
                    PdfPCell bizonylatVegosszegUresElso = new PdfPCell(new Phrase(""));
                    bizonylatVegosszegUresElso.Border = 0;
                    bizonylatVegosszegTabla.AddCell(bizonylatVegosszegUresElso);
                    PdfPCell bizonylatVegosszegUresMasodik = new PdfPCell(new Phrase(""));
                    bizonylatVegosszegUresMasodik.Border = 0;
                    bizonylatVegosszegTabla.AddCell(bizonylatVegosszegUresMasodik);
                    PdfPCell bizonylatVegosszegUresHarmadik = new PdfPCell(new Phrase(""));
                    bizonylatVegosszegUresHarmadik.Border = 0;
                    bizonylatVegosszegTabla.AddCell(bizonylatVegosszegUresHarmadik);
                    PdfPCell bizonylatVegosszegSz = new PdfPCell(new Phrase(bizonylatVegosszegSzoveg));
                    bizonylatVegosszegTabla.AddCell(bizonylatVegosszegSz);
                    PdfPCell bizonylatVegosszegA = new PdfPCell(new Phrase(bizonylatVegosszegAdat));
                    bizonylatVegosszegTabla.AddCell(bizonylatVegosszegA);
                    pdfSzamla.Add(bizonylatVegosszegTabla);
                    pdfSzamla.Add(new iTextSharp.text.Paragraph(" "));
                    #endregion

                    #region SzamlaVegosszeg
                    PdfPTable szamlaVegosszegTabla = new PdfPTable(5);
                    PdfPCell szamlaVegosszegSz = new PdfPCell(new Phrase(szamlaVegosszegSzoveg));
                    szamlaVegosszegTabla.AddCell(szamlaVegosszegSz);
                    PdfPCell szamlaVegosszegA = new PdfPCell(new Phrase(szamlaVegosszegAdat));
                    szamlaVegosszegTabla.AddCell(szamlaVegosszegA);
                    PdfPCell szamlaVegosszegUresElso = new PdfPCell(new Phrase(""));
                    szamlaVegosszegUresElso.Border = 0;
                    szamlaVegosszegTabla.AddCell(szamlaVegosszegUresElso);
                    PdfPCell szamlaVegosszegUresMasodik = new PdfPCell(new Phrase(""));
                    szamlaVegosszegUresMasodik.Border = 0;
                    szamlaVegosszegTabla.AddCell(szamlaVegosszegUresMasodik);
                    PdfPCell szamlaVegosszegUresHarmadik = new PdfPCell(new Phrase(""));
                    szamlaVegosszegUresHarmadik.Border = 0;
                    szamlaVegosszegTabla.AddCell(szamlaVegosszegUresHarmadik);
                    pdfSzamla.Add(szamlaVegosszegTabla);
                    #endregion
                    #region Vizjel
                    ColumnText.ShowTextAligned(kimenet.DirectContent, Element.ALIGN_CENTER, new Phrase(szamlaFizetve), 595 / 2, 425 / 2, 40);
                    #endregion

                    pdfSzamla.Close();
                    adatbazis.SubmitChanges();

                    MailMessage uzenet = new MailMessage();
                    SmtpClient smtp = new SmtpClient("smtp.gmail.com");
                    Attachment csatolmany = new Attachment(szamlaMenteseDialog.FileName, MediaTypeNames.Application.Octet);
                    ContentDisposition csatolmanyAttributumai = csatolmany.ContentDisposition;
                    csatolmanyAttributumai.CreationDate = System.IO.File.GetCreationTime(szamlaMenteseDialog.FileName);
                    csatolmanyAttributumai.ModificationDate = System.IO.File.GetLastWriteTime(szamlaMenteseDialog.FileName);
                    csatolmanyAttributumai.ReadDate = System.IO.File.GetLastAccessTime(szamlaMenteseDialog.FileName);
                    uzenet.Attachments.Add(csatolmany);

                    uzenet.From = new MailAddress("konyvesarmand@gmail.com");
                    uzenet.To.Add(jelenlegiVevo.Email);
                    uzenet.Subject = "Megrendelt konyv visszaigazolasa";
                    uzenet.Body = String.Concat("Tisztelt ", jelenlegiVevo.Vezeteknev, " ", jelenlegiVevo.Keresztnev, "!", "\n", "Ezuton kuldjuk megrendelt tetele(i)rol a kiallitott e-szamlat, csatolt pdf formatumban");

                    smtp.Port = 587;
                    smtp.Credentials = new System.Net.NetworkCredential("konyvesarmand", "qcrnbbsskbshovcg");
                    smtp.EnableSsl = true;
                    smtp.Send(uzenet);
                }
                catch (Exception)
                {
                    MessageBox.Show("Hiba! A tetelek listaja ures!");
                }
            }
            MessageBoxResult siker = MessageBox.Show("A kivant neven elmentettuk szamlajat es el is kuldtuk azt regisztralt email cimere!", "Koszonjuk!", MessageBoxButton.OK, MessageBoxImage.Information);

            if (siker == MessageBoxResult.OK)
            {
                KonyvesboltFelhasznaloFoablak konyvesboltFelhasznaloFoablak = new KonyvesboltFelhasznaloFoablak(ID);
                konyvesboltFelhasznaloFoablak.Show();
                this.Close();
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var konyv = (from k in adatbazis.Konyvs
                         where k.ID == konyvSora.ID
                         select k);
            dataGridSzamlaOsszesito.ItemsSource = konyv;
        }

        private void checkBoxASZF_Checked(object sender, RoutedEventArgs e)
        {
            checkboxEllenorzese();
        }

        private void checkBoxAdatkezelesiTajekoztato_Checked(object sender, RoutedEventArgs e)
        {
            checkboxEllenorzese();
        }
    }
}
