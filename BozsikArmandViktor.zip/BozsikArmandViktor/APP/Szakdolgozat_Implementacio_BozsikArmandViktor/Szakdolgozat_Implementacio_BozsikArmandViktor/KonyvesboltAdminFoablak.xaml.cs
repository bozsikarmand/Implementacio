﻿using System;
using System.Collections.Generic;
using System.Data.Linq.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LiveCharts;
using LiveCharts.Wpf;

namespace Szakdolgozat_Implementacio_BozsikArmandViktor
{
    /// <summary>
    /// Interaction logic for KonyvtarFoablak.xaml
    /// </summary>
    public partial class KonyvtarFoablak : Window
    {
        private int ID;
        public KonyvtarFoablak(int ID)
        {
            this.ID = ID;
            InitializeComponent();
        }

        /// <summary>
        /// A felhasznalok adminisztracios ablakat nyitja meg, majd a jelenlegit bezarja
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void menuItemFelhasznalo_Click(object sender, RoutedEventArgs e)
        {
            KonuvesboltAdminFelhasznalo konyvesboltAdminFelhasznalo = new KonuvesboltAdminFelhasznalo(ID);
            konyvesboltAdminFelhasznalo.Show();
            this.Close();
        }

        /// <summary>
        /// A konyvek adminisztracios ablakat nyitja meg, majd a jelenlegit bezarja
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void menuItemKonyv_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltAdminKonyv konyvesboltAdminKonyv = new KonyvesboltAdminKonyv(ID);
            konyvesboltAdminKonyv.Show();
            this.Close();
        }

        /// <summary>
        /// A szerzok adminisztracios ablakat nyitja meg, majd a jelenlegit bezarja
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void menuItemSzerzo_Click(object sender, RoutedEventArgs e)
        {
            KonuvesboltAdminSzerzo konyvesboltAdminSzerzo = new KonuvesboltAdminSzerzo(ID);
            konyvesboltAdminSzerzo.Show();
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var adminUdvozles = (from f in adatbazis.Felhasznalos
                                 where f.ID == ID
                                 select f).Single();

            labelAdminUdvozles.Content = String.Concat("Udvozlom, ", adminUdvozles.Vezeteknev, " ", adminUdvozles.Keresztnev, "!");

            Latogatas latogatas = new Latogatas();
            latogatas.Datum = DateTime.Now;
            latogatas.FelhasznaloID = ID;
            latogatas.Vasarolt = false;

            var konyvek = from ok in adatbazis.Konyvs
                          select ok;

            var konyvekSzama = konyvek.Count();

            var magyarKonyvek = (from mk in adatbazis.Konyvs
                                 where mk.Nyelv == "Magyar"
                                 select mk);

            var magyarKonyvekSzama = magyarKonyvek.Count();

            //labelMagyarKonyvek.Content = "Magyar nyelvu konyvek: " + magyarKonyvek.Count() + " db";

            var nemMagyarKonyvek = (from nmk in adatbazis.Konyvs
                                    where nmk.Nyelv != "Magyar"
                                    select nmk);

            var nemMagyarKonyvekSzama = nemMagyarKonyvek.Count();

            //labelNemMagyarKonyvek.Content = "Nem magyar nyelvu nyelvu konyvek: " + nemMagyarKonyvek.Count() + " db";

            konyvMegoszlasChart.Series.Add(
                new PieSeries
                {
                    Title = "Magyar",
                    Fill = Brushes.Red,
                    StrokeThickness = 0,
                    Values = new ChartValues<double>
                    {
                        magyarKonyvekSzama
                    }
                });

            konyvMegoszlasChart.Series.Add(
                new PieSeries
                {
                    Title = "Idegennyelvu",
                    Fill = Brushes.Blue,
                    StrokeThickness = 0,
                    Values = new ChartValues<double>
                    {
                        nemMagyarKonyvekSzama
                    }
                });

            var felhasznalokDarabszama = (from f in adatbazis.Felhasznalos
                                          orderby f.ID ascending
                                          select f.ID);

            indulasOtaRegisztraltFelhasznalokChart.Series.Add(
                new LineSeries
                {
                    Title = "\u03A3",
                    Values = new ChartValues<int>(felhasznalokDarabszama)
                });

            var felhasznaloiLatogatottsag = from fl in adatbazis.Latogatas
                                            orderby fl.ID ascending
                                            select fl.ID;

            felhasznaloiLatogatottsagChart.Series.Add(
                new LineSeries
                {
                    Title = "Latogatasok szama",
                    Values = new ChartValues<int>(felhasznaloiLatogatottsag)
                });
        }

        private void buttonKilepes_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void PieChart_Loaded(object sender, RoutedEventArgs e)
        {
            
        }

        private void CartesianChart_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void menuItemFelhasznaloiAdatok_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltFelhasznaloAdatai konyvesboltFelhasznaloAdatai = new KonyvesboltFelhasznaloAdatai(ID);
            konyvesboltFelhasznaloAdatai.Show();
            this.Close();
        }
    }
}
