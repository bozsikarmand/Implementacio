﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Szakdolgozat_Implementacio_BozsikArmandViktor
{
    /// <summary>
    /// Interaction logic for KonyvesboltFelhasznaloAdatai.xaml
    /// </summary>
    public partial class KonyvesboltFelhasznaloAdatai : Window
    {
        private int ID;
        private string Jelszo;
        public KonyvesboltFelhasznaloAdatai(int ID)
        {
            this.ID = ID;
            InitializeComponent();
        }
        public KonyvesboltFelhasznaloAdatai(int ID, string Jelszo)
        {
            this.ID = ID;
            this.Jelszo = Jelszo;
            InitializeComponent();
        }

        int erdeklodesiKorID = 0;
        List<CheckBox> erdeklodesiKorCB = new List<CheckBox>();
        bool hazszamHelyes = true;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var felhasznaloAdatai = (from f in adatbazis.Felhasznalos
                                      where f.ID == ID
                                      select f).Single();

            textBoxVezeteknev.Text = felhasznaloAdatai.Vezeteknev;
            textBoxKeresztnev.Text = felhasznaloAdatai.Keresztnev;
            textBoxUtonev.Text = felhasznaloAdatai.Utonev;
            textBoxFelhNev.Text = felhasznaloAdatai.FelhNev;
            dateTimePickerSzulDatum.Value = felhasznaloAdatai.SzulDatum;
            maskedTextBoxEmail.Text = felhasznaloAdatai.Email;
            textBoxTel.Text = felhasznaloAdatai.Tel;
            //textBoxHirlevel.Text = felhasznaloAdatai.Hirlevel.ToString();
            checkBoxHirlevel.IsChecked = (bool)felhasznaloAdatai.Hirlevel;
            passwordBoxJelszo.Password = felhasznaloAdatai.Jelszo;
            dateTimePickerNevnap.Value = felhasznaloAdatai.Nevnap;
            textBoxVaros.Text = felhasznaloAdatai.Varos;
            textBoxUtca.Text = felhasznaloAdatai.Utca;
            textBoxHazszam.Text = Convert.ToString(felhasznaloAdatai.Hazszam);
            
            int erdeklodesiKorIDAdatbazisbol = felhasznaloAdatai.ErdeklodesiKorID;

            erdeklodesiKorCB.Add(checkBoxKategoriaIsmeretterjeszto);
            erdeklodesiKorCB.Add(checkBoxKategoriaSzamitastechnika);
            erdeklodesiKorCB.Add(checkBoxKategoriaIrodalom);
            erdeklodesiKorCB.Add(checkBoxKategoriaTortenelemEsEmber);
            erdeklodesiKorCB.Add(checkBoxKategoriaKlasszikusTudomanyok);
            erdeklodesiKorCB.Add(checkBoxKategoriaOktatas);

            erdeklodesiKorCB[erdeklodesiKorIDAdatbazisbol-1].IsChecked = true;
        }

        private void buttonFelhasznaloAdatokModositasa_Click(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var felhasznaloAdatai = (from f in adatbazis.Felhasznalos
                                     where f.ID == ID
                                     select f).Single();

            if (!textBoxHazszam.Text.All(char.IsDigit))
            {
                hazszamHelyes = false;
                MessageBox.Show("A megadott hazszam nem megengedett formatumu!", "A megadott hazszam nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                hazszamHelyes = true;
            }
            if (Jelszo != null)
            {
                felhasznaloAdatai.Jelszo = Jelszo;
            }
            if (Jelszo == null)
            {
                felhasznaloAdatai.Jelszo = passwordBoxJelszo.Password;
            }
            if (hazszamHelyes == false)
            {
                textBoxHazszam.Text = "";
            }
            if (hazszamHelyes)
            {
                felhasznaloAdatai.Hazszam = Convert.ToInt32(textBoxHazszam.Text);
                felhasznaloAdatai.Vezeteknev = textBoxVezeteknev.Text;
                felhasznaloAdatai.Keresztnev = textBoxKeresztnev.Text;
                felhasznaloAdatai.Utonev = textBoxUtonev.Text;
                felhasznaloAdatai.FelhNev = textBoxFelhNev.Text;
                felhasznaloAdatai.SzulDatum = DateTime.ParseExact(dateTimePickerSzulDatum.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                felhasznaloAdatai.Email = maskedTextBoxEmail.Text;
                felhasznaloAdatai.Tel = textBoxTel.Text;
                felhasznaloAdatai.Hirlevel = checkBoxHirlevel.IsChecked.Value;
                felhasznaloAdatai.Nevnap = DateTime.ParseExact(dateTimePickerNevnap.Text, "MM-dd", CultureInfo.InvariantCulture);
                felhasznaloAdatai.Varos = textBoxVaros.Text;
                felhasznaloAdatai.Utca = textBoxUtca.Text;
                //felhasznaloAdatai.ErdeklodesiKorID = Convert.ToInt32(textBoxErdeklodesiKorID.Text);
                felhasznaloAdatai.ErdeklodesiKorID = erdeklodesiKorID;
                adatbazis.SubmitChanges();
                MessageBox.Show("Adatait sikeresen frissitettuk!", "Adatait sikeresen frissitettuk!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void checkBoxKategoriaIsmeretterjeszto_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[0].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 1;
            }
        }

        private void checkBoxKategoriaIsmeretterjeszto_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;
            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }

        private void checkBoxKategoriaSzamitastechnika_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[1].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 2;
            }
        }

        private void checkBoxKategoriaSzamitastechnika_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;

            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }

        private void checkBoxKategoriaIrodalom_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[2].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 3;
            }
        }

        private void checkBoxKategoriaIrodalom_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;

            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }

        private void checkBoxKategoriaTortenelemEsEmber_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[3].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 4;
            }
        }

        private void checkBoxKategoriaTortenelemEsEmber_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;

            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }

        private void checkBoxKategoriaKlasszikusTudomanyok_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[4].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 5;
            }
        }

        private void checkBoxKategoriaKlasszikusTudomanyok_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;

            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }

        private void checkBoxKategoriaOktatas_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[5].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 6;
            }
        }

        private void checkBoxKategoriaOktatas_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;

            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }

        private void buttonJelszoModositasa_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltJelszoModositasa konyvesboltJelszoModositasa = new KonyvesboltJelszoModositasa(ID);
            konyvesboltJelszoModositasa.Show();
            this.Close();
        }

        private void buttonVasarlasokMegtekintese_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltFelhasznaloVasarlasai konyvesboltFelhasznaloVasarlasai = new KonyvesboltFelhasznaloVasarlasai(ID);
            konyvesboltFelhasznaloVasarlasai.Show();
            this.Close();
        }

        private void buttonVisszaFooldalra_Click(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var felhasznaloID = (from ft
                                 in adatbazis.Felhasznalos
                                 where ft.ID == ID
                                 select ft.ID).Single();

            var felhasznaloJog = (from ft
                                  in adatbazis.Felhasznalos
                                  where ft.ID == ID
                                  select ft.Jog.Nev).Single();



            if (felhasznaloJog.Equals("Adminisztrator"))
            {
                KonyvtarFoablak konyvesboltAdminisztratorFoablak = new KonyvtarFoablak(felhasznaloID);
                konyvesboltAdminisztratorFoablak.Show();
                this.Close();
            }
            if (felhasznaloJog.Equals("Felhasznalo"))
            {
                KonyvesboltFelhasznaloFoablak konyvesboltFelhasznaloFoablak = new KonyvesboltFelhasznaloFoablak(felhasznaloID);
                konyvesboltFelhasznaloFoablak.Show();
                this.Close();
            }
        }
    }
}
