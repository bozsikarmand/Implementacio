﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Szakdolgozat_Implementacio_BozsikArmandViktor
{
    /// <summary>
    /// Interaction logic for KonuvesboltAdminFelhasznalo.xaml
    /// </summary>
    public partial class KonuvesboltAdminFelhasznalo : Window
    {
        private int ID;
        public KonuvesboltAdminFelhasznalo(int ID)
        {
            this.ID = ID;
            InitializeComponent();
            DataGridFeltoltese();
        }

        int erdeklodesiKorID = 0;
        List<CheckBox> erdeklodesiKorCB = new List<CheckBox>();

        private void DataGridFeltoltese()
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var felhasznalo = (from f in adatbazis.Felhasznalos select f);
            dataGridFelhasznalo.ItemsSource = felhasznalo;
        }

        private void DataGridFrissitese()
        {
            try
            {
                AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
                Felhasznalo felhasznaloSora = dataGridFelhasznalo.SelectedItem as Felhasznalo;

                var id = felhasznaloSora.ID;
                Felhasznalo felhasznalo = (from f in adatbazis.Felhasznalos
                                           where f.ID == felhasznaloSora.ID
                                           select f).Single();
                felhasznalo.Vezeteknev = felhasznaloSora.Vezeteknev;
                felhasznalo.Keresztnev = felhasznaloSora.Keresztnev;
                felhasznalo.Utonev = felhasznaloSora.Utonev;
                felhasznalo.FelhNev = felhasznaloSora.FelhNev;
                felhasznalo.SzulDatum = felhasznaloSora.SzulDatum;
                felhasznalo.Email = felhasznaloSora.Email;
                felhasznalo.Tel = felhasznaloSora.Tel;
                felhasznalo.Hirlevel = felhasznaloSora.Hirlevel;
                felhasznalo.Jelszo = felhasznaloSora.Jelszo;
                felhasznalo.Nevnap = felhasznaloSora.Nevnap;
                felhasznalo.Varos = felhasznaloSora.Varos;
                felhasznalo.Utca = felhasznaloSora.Utca;
                felhasznalo.Hazszam = felhasznaloSora.Hazszam;
                felhasznalo.ErdeklodesiKorID = felhasznaloSora.ErdeklodesiKorID;
                felhasznalo.JogID = felhasznaloSora.JogID;

                adatbazis.SubmitChanges();
                MessageBox.Show("A felhasznalo sikeresen frissitve!");
                DataGridFeltoltese();
            }
            catch (Exception ex)
            {
                
            }
        }

        private void DataGridElemTorlese()
        {
            try
            {
                AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
                Felhasznalo felhasznaloSora = dataGridFelhasznalo.SelectedItem as Felhasznalo;

                var felhasznalo = (from f in adatbazis.Felhasznalos
                                   where f.ID == felhasznaloSora.ID
                                   select f).Single();
                adatbazis.Felhasznalos.DeleteOnSubmit(felhasznalo);
                adatbazis.SubmitChanges();
                MessageBox.Show("A felhasznalo sikeresen torolve!");
                DataGridFeltoltese();
            }
            catch (Exception ex)
            {
                
            }
        }

        /// <summary>
        /// dataGrid frissitese modositas utan
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonModositas_Click(object sender, RoutedEventArgs e)
        {
            DataGridFrissitese();
        }

        /// <summary>
        /// dataGrid elem torlese
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonTorles_Click(object sender, RoutedEventArgs e)
        {
            DataGridElemTorlese();
        }

        private void DataGridElemHozzaadasa()
        {
            try
            {
                AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
                Felhasznalo felhasznalo = new Felhasznalo();

                bool helyesAJelszo = true;

                var felhasznaloiNev = (from f
                                       in adatbazis.Felhasznalos
                                       where f.FelhNev == textBoxFelhNev.Text
                                       select f.FelhNev).SingleOrDefault();

                bool egyezikAFelhasznaloiNev = false;
                bool kisbetusFelhasznaloiNev = true;
                bool joAFelhNevHossza = true;
                bool hazszamHelyes = true;

                if (passwordBoxJelszo.Password != passwordBoxJelszoMegint.Password)
                {
                    helyesAJelszo = false;
                    MessageBox.Show("A megadott jelszavak nem egyeznek!", "A jelszavak nem megfeleloek!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                if (passwordBoxJelszo.Password.Length < 16)
                {
                    helyesAJelszo = false;
                    MessageBox.Show("A megadott uj jelszo kevesebb mint 16 karakter!", "Az uj jelszo nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);

                }
                if (passwordBoxJelszoMegint.Password.Length < 16)
                {
                    helyesAJelszo = false;
                    MessageBox.Show("A megadott uj jelszo megerositese nem sikeres, mivel kevesebb mint 16 karakter!", "Az uj jelszo megerositese nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                if (!passwordBoxJelszo.Password.Any(char.IsUpper))
                {
                    helyesAJelszo = false;
                    MessageBox.Show("A megadott uj jelszo nem tartalmaz nagybetut! (pl. A, B, C, D, E, F, G, H)", "Az uj jelszo megerositese nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                if (!passwordBoxJelszo.Password.Any(char.IsDigit))
                {
                    helyesAJelszo = false;
                    MessageBox.Show("A megadott uj jelszo nem tartalmaz szamot! (pl. 1, 2, 3, 4, 5, 6, 7, 8)", "Az uj jelszo megerositese nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                if (!textBoxFelhNev.Text.All(char.IsLower))
                {
                    kisbetusFelhasznaloiNev = false;
                    MessageBox.Show("A megadott felhasznalonev nagybetut tartalmaz! (pl. A, B, C, D, E, F, G, H)", "A valasztott felhasznaloi nev nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                if (textBoxFelhNev.Text.Length < 3)
                {
                    joAFelhNevHossza = false;
                    MessageBox.Show("A megadott felhasznaloi nev rovidebb mint 3 karakter!", "A valasztott felhasznaloi nev nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                if (!textBoxHazszam.Text.All(char.IsDigit))
                {
                    hazszamHelyes = false;
                    MessageBox.Show("A megadott hazszam nem megengedett formatumu!", "A megadott hazszam nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                if (felhasznaloiNev == null)
                {
                    if (kisbetusFelhasznaloiNev == false || joAFelhNevHossza == false)
                    {
                        textBoxFelhNev.Text = "";
                    }
                    if (hazszamHelyes == false)
                    {
                        textBoxHazszam.Text = "";
                    }
                    if (helyesAJelszo == false)
                    {
                        passwordBoxJelszo.Password = "";
                        passwordBoxJelszoMegint.Password = "";
                    }
                    else 
                    {
                        egyezikAFelhasznaloiNev = false;

                        if (helyesAJelszo == false)
                        {
                            passwordBoxJelszo.Password = "";
                            passwordBoxJelszoMegint.Password = "";
                        }
                        else
                        {
                            try
                            {
                                felhasznalo.Vezeteknev = textBoxVezeteknev.Text;
                                felhasznalo.Keresztnev = textBoxKeresztnev.Text;
                                felhasznalo.Utonev = textBoxUtonev.Text;
                                felhasznalo.FelhNev = textBoxFelhNev.Text;
                                felhasznalo.SzulDatum = DateTime.ParseExact(dateTimePickerSzulDatum.Text, "yyyy-MM-dd", CultureInfo.InvariantCulture); // !
                                felhasznalo.Email = maskedTextBoxEmail.Text;
                                felhasznalo.Tel = textBoxTel.Text;
                                felhasznalo.Hirlevel = Convert.ToBoolean(checkBoxHirlevel.IsChecked.Value); // !
                                felhasznalo.Jelszo = BCrypt.Net.BCrypt.EnhancedHashPassword(passwordBoxJelszo.Password);
                                felhasznalo.Nevnap = DateTime.ParseExact(dateTimePickerNevnap.Text, "MM-dd", CultureInfo.InvariantCulture); // !
                                felhasznalo.Varos = textBoxVaros.Text;
                                felhasznalo.Utca = textBoxUtca.Text;
                                felhasznalo.Hazszam = Convert.ToInt32(textBoxHazszam.Text);
                                felhasznalo.ErdeklodesiKorID = erdeklodesiKorID;
                                felhasznalo.JogID = 1;

                                adatbazis.Felhasznalos.InsertOnSubmit(felhasznalo);
                                adatbazis.SubmitChanges();
                                MessageBox.Show("Az uj adminisztrator sikeresen felvetelre kerult a rendszerbe!");
                                DataGridFeltoltese();
                            }
                            catch
                            {
                                MessageBox.Show("Az adminisztrator regisztracioja kozben hiba(ka)t eszleltunk! Kerem tekintse at es javitsa a munkavallalo adatait, majd probalja ujra az urlap elkuldeset!", "Tajekoztatas", MessageBoxButton.OK, MessageBoxImage.Stop);
                            }
                        }
                    }
                }
                else if (felhasznaloiNev.Equals(textBoxFelhNev.Text))
                {
                    egyezikAFelhasznaloiNev = true;
                    if (egyezikAFelhasznaloiNev)
                    {
                        MessageBox.Show("A kivant felhasznalonevvel mar regisztraltak rendszerunkbe!", "A valasztott felhasznalonev nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
                        textBoxFelhNev.Text = "";
                    }
                    if (helyesAJelszo == false)
                    {
                        passwordBoxJelszo.Password = "";
                        passwordBoxJelszoMegint.Password = "";
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Helytelen adat!", "HIBA!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// dataGrid elem hozzadasa
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonHozzaadas_Click(object sender, RoutedEventArgs e)
        {
            DataGridElemHozzaadasa();
        }

        private void menuItemKonyv_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void menuItemKonyv_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltAdminKonyv konyvesboltAdminKonyv = new KonyvesboltAdminKonyv(ID);
            konyvesboltAdminKonyv.Show();
            this.Close();
        }

        private void menuItemSzerzo_Click(object sender, RoutedEventArgs e)
        {
            KonuvesboltAdminSzerzo konuvesboltAdminSzerzo = new KonuvesboltAdminSzerzo(ID);
            konuvesboltAdminSzerzo.Show();
            this.Close();
        }

        private void textBoxVezeteknev_GotFocus(object sender, RoutedEventArgs e)
        {

        }

        private void textBoxVezeteknev_LostFocus(object sender, RoutedEventArgs e)
        {

        }

        private void textBoxKeresztnev_GotFocus(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorCB.Add(checkBoxKategoriaIsmeretterjeszto);
            erdeklodesiKorCB.Add(checkBoxKategoriaSzamitastechnika);
            erdeklodesiKorCB.Add(checkBoxKategoriaIrodalom);
            erdeklodesiKorCB.Add(checkBoxKategoriaTortenelemEsEmber);
            erdeklodesiKorCB.Add(checkBoxKategoriaKlasszikusTudomanyok);
            erdeklodesiKorCB.Add(checkBoxKategoriaOktatas);

            if (checkBoxKategoriaIsmeretterjeszto.IsChecked == false)
            {
                checkBoxKategoriaIsmeretterjeszto.IsChecked = true;
            }
            dataGridFelhasznalo.CanUserAddRows = false;
        }

        private void dataGridFelhasznalo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            Felhasznalo felhasznaloSora = dataGridFelhasznalo.SelectedItem as Felhasznalo;

            if (felhasznaloSora != null)
            {
                var felhasznalo = (from f in adatbazis.Felhasznalos
                               where f.ID == felhasznaloSora.ID
                               select f).SingleOrDefault();

                if (felhasznalo != null)
                {
                    var felhasznaloVasarlasai = (from FelhasznaloKonyvs in adatbazis.FelhasznaloKonyvs
                                                 from Felhasznalos in adatbazis.Felhasznalos
                                                 where
                                                 FelhasznaloKonyvs.FelhasznaloID == felhasznalo.ID
                                                 select new
                                                 {
                                                     FelhasznaloKonyvs.Konyv.Cim,
                                                     FelhasznaloKonyvs.Konyv.Ar
                                                 }).Distinct();

                    if (felhasznaloVasarlasai != null)
                    {
                        dataGridFelhasznaloVasarlasai.ItemsSource = felhasznaloVasarlasai;

                        var felhasznaloSzamlai = (from Szamlas in adatbazis.Szamlas
                                                  from Felhasznalos in adatbazis.Felhasznalos
                                                  where
                                                    Szamlas.KonyvID == Szamlas.FelhasznaloKonyv.KonyvID &&
                                                    Szamlas.FelhasznaloKonyv.FelhasznaloID == felhasznalo.ID
                                                  select new
                                                  {
                                                      Szamlas.ID,
                                                      Szamlas.KonyvID,
                                                      Szamlas.Tartalom
                                                  }).Distinct();

                        if (dataGridFelhasznaloVasarlasai.Items.Count != 0)
                        {
                            if (felhasznaloSzamlai != null)
                            {
                                dataGridFelhasznaloSzamlai.ItemsSource = felhasznaloSzamlai;
                            }
                            else
                            {
                                string felhasznaloMegNemKapottSzamlat = "A felhasznalonak meg nincs szamlaja!";
                                dataGridFelhasznaloSzamlai.ItemsSource = felhasznaloMegNemKapottSzamlat;
                            }
                        }
                    }
                    else
                    {
                        string aFelhasznaloMegNemVasarolt = "A felhasznalo meg nem vasarolt!";
                        dataGridFelhasznaloVasarlasai.ItemsSource = aFelhasznaloMegNemVasarolt;
                    }
                }
            }
            else
            {
                MessageBox.Show("Az elozoleg kijelolt listaelem allapotaban valtozas tortent!", "Kerem valasszon listaelemet!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void buttonVisszaAdminFooldalra_Click(object sender, RoutedEventArgs e)
        {
            KonyvtarFoablak konyvesboltAdminFoablak = new KonyvtarFoablak(ID);
            konyvesboltAdminFoablak.Show();
            this.Close();
        }

        private void checkBoxKategoriaIsmeretterjeszto_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[0].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 1;
            }
        }

        private void checkBoxKategoriaIsmeretterjeszto_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;
            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }

        private void checkBoxKategoriaSzamitastechnika_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[1].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 2;
            }
        }

        private void checkBoxKategoriaSzamitastechnika_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;

            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }

        private void checkBoxKategoriaIrodalom_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[2].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 3;
            }
        }

        private void checkBoxKategoriaIrodalom_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;

            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }

        private void checkBoxKategoriaTortenelemEsEmber_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[3].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 4;
            }
        }

        private void checkBoxKategoriaTortenelemEsEmber_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;

            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }

        private void checkBoxKategoriaKlasszikusTudomanyok_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[4].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 5;
            }
        }

        private void checkBoxKategoriaKlasszikusTudomanyok_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;

            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }

        private void checkBoxKategoriaOktatas_Checked(object sender, RoutedEventArgs e)
        {
            if (erdeklodesiKorCB[5].IsChecked == true)
            {
                foreach (var i in erdeklodesiKorCB)
                {
                    if (!i.IsChecked == true)
                    {
                        i.IsEnabled = false;
                    }
                }

                erdeklodesiKorID = 6;
            }
        }

        private void checkBoxKategoriaOktatas_Unchecked(object sender, RoutedEventArgs e)
        {
            erdeklodesiKorID = 0;

            checkBoxKategoriaIsmeretterjeszto.IsEnabled = true;
            checkBoxKategoriaSzamitastechnika.IsEnabled = true;
            checkBoxKategoriaIrodalom.IsEnabled = true;
            checkBoxKategoriaTortenelemEsEmber.IsEnabled = true;
            checkBoxKategoriaKlasszikusTudomanyok.IsEnabled = true;
            checkBoxKategoriaOktatas.IsEnabled = true;
        }
    }
}
