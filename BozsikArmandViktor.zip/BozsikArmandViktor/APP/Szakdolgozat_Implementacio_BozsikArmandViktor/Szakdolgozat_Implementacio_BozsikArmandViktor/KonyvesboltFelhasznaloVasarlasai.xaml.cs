﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Szakdolgozat_Implementacio_BozsikArmandViktor
{
    /// <summary>
    /// Interaction logic for KonyvesboltFelhasznaloVasarlasai.xaml
    /// </summary>
    public partial class KonyvesboltFelhasznaloVasarlasai : Window
    {
        private int ID;
        public KonyvesboltFelhasznaloVasarlasai(int ID)
        {
            this.ID = ID;
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();

            var felhasznalo = (from f in adatbazis.Felhasznalos
                               where f.ID == ID
                               select f).Single();

            var felhasznaloVasarlasai = (from FelhasznaloKonyvs in adatbazis.FelhasznaloKonyvs
                                         from Felhasznalos in adatbazis.Felhasznalos
                                         where
                                         FelhasznaloKonyvs.FelhasznaloID == felhasznalo.ID
                                         select new
                                         {
                                             FelhasznaloKonyvs.Konyv.Cim,
                                             FelhasznaloKonyvs.Konyv.Ar
                                         }).Distinct();

            dataGridFelhasznaloVasarlasai.ItemsSource = felhasznaloVasarlasai;
        }

        private void menuItemKapcsolatfelvetel_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltFelhasznaloKapcsolatfelvetel konyvesboltFelhasznaloKapcsolatfelvetel = new KonyvesboltFelhasznaloKapcsolatfelvetel(ID);
            konyvesboltFelhasznaloKapcsolatfelvetel.Show();
            this.Close();
        }

        private void menuItemLegujabbKonyvek_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltFelhasznaloLegujabbKonyvek konyvesboltFelhasznaloLegujabbKonyvek = new KonyvesboltFelhasznaloLegujabbKonyvek(ID);
            konyvesboltFelhasznaloLegujabbKonyvek.Show();
            this.Close();
        }

        private void menuItemAjanlottKonyvek_Click(object sender, RoutedEventArgs e)
        {
            KonyvesboltFelhasznaloAjanlottKonyvek konyvesboltFelhasznaloAjanlottKonyvek = new KonyvesboltFelhasznaloAjanlottKonyvek(ID);
            konyvesboltFelhasznaloAjanlottKonyvek.Show();
            this.Close();
        }

        private void buttonVisszaFooldalra_Click(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var felhasznaloID = (from ft
                                 in adatbazis.Felhasznalos
                                 where ft.ID == ID
                                 select ft.ID).Single();

            var felhasznaloJog = (from ft
                                  in adatbazis.Felhasznalos
                                  where ft.ID == ID
                                  select ft.Jog.Nev).Single();



            if (felhasznaloJog.Equals("Adminisztrator"))
            {
                KonyvtarFoablak konyvesboltAdminisztratorFoablak = new KonyvtarFoablak(felhasznaloID);
                konyvesboltAdminisztratorFoablak.Show();
                this.Close();
            }
            if (felhasznaloJog.Equals("Felhasznalo"))
            {
                KonyvesboltFelhasznaloFoablak konyvesboltFelhasznaloFoablak = new KonyvesboltFelhasznaloFoablak(felhasznaloID);
                konyvesboltFelhasznaloFoablak.Show();
                this.Close();
            }
        }
    }
}
