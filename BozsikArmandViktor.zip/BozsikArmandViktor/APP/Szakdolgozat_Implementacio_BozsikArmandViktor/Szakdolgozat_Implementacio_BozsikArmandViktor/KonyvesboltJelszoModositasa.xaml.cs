﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BCrypt.Net;

namespace Szakdolgozat_Implementacio_BozsikArmandViktor
{
    /// <summary>
    /// Interaction logic for KonyvesboltJelszoModositasa.xaml
    /// </summary>
    public partial class KonyvesboltJelszoModositasa : Window
    {
        private int ID;
        public KonyvesboltJelszoModositasa(int ID)
        {
            this.ID = ID;
            InitializeComponent();
        }

        private void buttonJelszoModositasa_Click(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var felhasznaloAdatai = (from f in adatbazis.Felhasznalos
                                     where f.ID == ID
                                     select f).Single();

            var felhasznaloJelenlegiJelszo = felhasznaloAdatai.Jelszo;

            bool helyesAJelszo = true;

            //string[] specialisKarakterek = new string[] { "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "_", "+", "-", "=" };

            if (passwordBoxUjJelszo.Password.ToString() != passwordBoxUjJelszoMegint.Password.ToString())
            {
                helyesAJelszo = false;
                MessageBox.Show("A megadott jelszavak nem egyeznek!", "A jelszavak nem megfeleloek!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            if (felhasznaloAdatai.JogID == 1 && passwordBoxUjJelszo.Password.Length < 16)
            {
                helyesAJelszo = false;
                MessageBox.Show("A megadott uj jelszo kevesebb mint 16 karakter!", "Az uj jelszo nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            if (felhasznaloAdatai.JogID == 1 && passwordBoxUjJelszoMegint.Password.Length < 16)
            {
                helyesAJelszo = false;
                MessageBox.Show("A megadott uj jelszo megerositese nem sikeres, mivel kevesebb mint 16 karakter!", "Az uj jelszo megerositese nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            if (felhasznaloAdatai.JogID == 2 && passwordBoxUjJelszo.Password.Length < 8)
            {
                helyesAJelszo = false;
                MessageBox.Show("A megadott uj jelszo kevesebb mint 8 karakter!", "Az uj jelszo nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            if (felhasznaloAdatai.JogID == 2 && passwordBoxUjJelszoMegint.Password.Length < 8)
            {
                helyesAJelszo = false;
                MessageBox.Show("A megadott uj jelszo megerositese nem sikeres, mivel kevesebb mint 8 karakter!", "Az uj jelszo megerositese nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            if (!passwordBoxUjJelszo.Password.Any(char.IsUpper))
            {
                helyesAJelszo = false;
                MessageBox.Show("A megadott uj jelszo nem tartalmaz nagybetut! (pl. A, B, C, D, E, F, G, H)", "Az uj jelszo megerositese nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            if (!passwordBoxUjJelszo.Password.Any(char.IsDigit))
            {
                helyesAJelszo = false;
                MessageBox.Show("A megadott uj jelszo  nem tartalmaz szamot! (pl. 1, 2, 3, 4, 5, 6, 7, 8)", "Az uj jelszo megerositese nem megfelelo!", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            if (helyesAJelszo == false)
            {
                passwordBoxUjJelszo.Password = "";
                passwordBoxUjJelszoMegint.Password = "";
            }
            else
            {
                var felhasznaloUjJelszo = passwordBoxUjJelszo.Password;
                var felhasznaloUjJelszoHash = BCrypt.Net.BCrypt.EnhancedHashPassword(felhasznaloUjJelszo);

                KonyvesboltFelhasznaloAdatai konyvesboltFelhasznaloAdatai = new KonyvesboltFelhasznaloAdatai(ID, felhasznaloUjJelszoHash);
                konyvesboltFelhasznaloAdatai.Show();
                this.Close();
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var felhasznaloAdatai = (from f in adatbazis.Felhasznalos
                                     where f.ID == ID
                                     select f).Single();

            passwordBoxJelszo.Password = felhasznaloAdatai.Jelszo;
        }

        private void buttonVissza_Click(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var felhasznaloID = (from ft
                                 in adatbazis.Felhasznalos
                                 where ft.ID == ID
                                 select ft.ID).Single();

            var felhasznaloJog = (from ft
                                  in adatbazis.Felhasznalos
                                  where ft.ID == ID
                                  select ft.Jog.Nev).Single();



            if (felhasznaloJog.Equals("Adminisztrator"))
            {
                KonyvtarFoablak konyvesboltAdminisztratorFoablak = new KonyvtarFoablak(felhasznaloID);
                konyvesboltAdminisztratorFoablak.Show();
                this.Close();
            }
            if (felhasznaloJog.Equals("Felhasznalo"))
            {
                KonyvesboltFelhasznaloFoablak konyvesboltFelhasznaloFoablak = new KonyvesboltFelhasznaloFoablak(felhasznaloID);
                konyvesboltFelhasznaloFoablak.Show();
                this.Close();
            }
        }
    }
}
