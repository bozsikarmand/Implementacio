﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Net.Mail;
using System.Net;
using System.Diagnostics;

namespace Szakdolgozat_Implementacio_BozsikArmandViktor
{
    /// <summary>
    /// Interaction logic for KonyvesboltFelhasznaloKapcsolatfelvetel.xaml
    /// </summary>
    public partial class KonyvesboltFelhasznaloKapcsolatfelvetel : Window
    {
        private int ID;
        public KonyvesboltFelhasznaloKapcsolatfelvetel(int ID)
        {
            this.ID = ID;
            InitializeComponent();
        }

        private void buttonUzenetKuldese_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                MailMessage uzenet = new MailMessage();
                SmtpClient smtp = new SmtpClient("smtp.gmail.com");

                uzenet.From = new MailAddress(textBoxEMail.Text);
                uzenet.To.Add("konyvesarmand@gmail.com");
                uzenet.Subject = "Uzenet erkezett egy regisztralt felhasznalotol!";
                uzenet.Body = "Nev: " + textBoxNev.Text + 
                              "\n" + 
                              "Email: " + textBoxEMail.Text + 
                              "\n\n" + 
                              "Uzenet:\n\n" + textBoxUzenet.Text;

                smtp.Port = 587;
                smtp.Credentials = new NetworkCredential("konyvesarmand", "qcrnbbsskbshovcg");
                smtp.EnableSsl = true;
                smtp.Send(uzenet);

                MessageBox.Show("Az uzenete elkuldesre kerult munkatarsaink szamara!");
            }
            catch (Exception)
            {
                MessageBox.Show("HIBA!", "HIBA!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var felhasznalo = (from f
                               in adatbazis.Felhasznalos
                               where f.ID == ID
                               select f).Single();
            textBoxNev.Text = String.Concat(felhasznalo.Vezeteknev, " ", felhasznalo.Keresztnev);
            textBoxEMail.Text = felhasznalo.Email;
        }

        private void buttonFacebook_Click(object sender, RoutedEventArgs e)
        {
            Process.Start("https://facebook.com/bozsikarmand");
        }

        private void buttonTwitter_Click(object sender, RoutedEventArgs e)
        {
            Process.Start("https://twitter.com/bozsikarmand");
        }

        private void buttonVisszaFooldalra_Click(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var felhasznaloID = (from ft
                                 in adatbazis.Felhasznalos
                                 where ft.ID == ID
                                 select ft.ID).Single();

            var felhasznaloJog = (from ft
                                  in adatbazis.Felhasznalos
                                  where ft.ID == ID
                                  select ft.Jog.Nev).Single();

            if (felhasznaloJog.Equals("Adminisztrator"))
            {
                KonyvtarFoablak konyvesboltAdminisztratorFoablak = new KonyvtarFoablak(felhasznaloID);
                konyvesboltAdminisztratorFoablak.Show();
                this.Close();
            }
            if (felhasznaloJog.Equals("Felhasznalo"))
            {
                KonyvesboltFelhasznaloFoablak konyvesboltFelhasznaloFoablak = new KonyvesboltFelhasznaloFoablak(felhasznaloID);
                konyvesboltFelhasznaloFoablak.Show();
                this.Close();
            }
        }
    }
}
