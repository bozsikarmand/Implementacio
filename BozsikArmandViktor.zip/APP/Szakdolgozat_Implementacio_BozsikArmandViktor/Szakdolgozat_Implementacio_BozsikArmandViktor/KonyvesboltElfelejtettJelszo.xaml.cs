﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace Szakdolgozat_Implementacio_BozsikArmandViktor
{
    /// <summary>
    /// Interaction logic for KonyvesboltElfelejtettJelszo.xaml
    /// </summary>
    public partial class KonyvesboltElfelejtettJelszo : Window
    {
        public KonyvesboltElfelejtettJelszo()
        {
            InitializeComponent();
        }

        private void buttonJelszoKerese_Click(object sender, RoutedEventArgs e)
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var felhasznalo = (from f
                               in adatbazis.Felhasznalos
                               where f.FelhNev == textBoxFelhNev.Text
                               select f).Single();

            Random r = new Random();

            var randomNev = System.IO.Path.GetRandomFileName();
            randomNev = randomNev.Replace(".", "");
            randomNev = randomNev.Replace(randomNev[0], char.ToUpper((char)r.Next('A','Z')));
            var ideiglenesJelszo = string.Concat(randomNev.Take(8));

            felhasznalo.Jelszo = BCrypt.Net.BCrypt.EnhancedHashPassword(ideiglenesJelszo);
            adatbazis.SubmitChanges();

            MailMessage uzenet = new MailMessage();
            SmtpClient smtp = new SmtpClient("smtp.gmail.com");

            uzenet.From = new MailAddress("konyvesarmand@gmail.com");
            uzenet.To.Add(felhasznalo.Email);
            uzenet.Subject = "Ideiglenes jelszo kikuldese. Kerem valtoztassa meg az elso belepesnel!";
            uzenet.Body = String.Concat("Tisztelt ", felhasznalo.Vezeteknev, " ", felhasznalo.Keresztnev, "!", "\n\n", "Jelszopotlast kezdemenyezett alkalmazasunkban, igy ezuton kuldjuk ideiglenes jelszavat:\n\n" + ideiglenesJelszo + "\n\nAmennyiben nem On kezdemenyezte a jelszocseret, kerem valaszoljon ezen levelre!");

            smtp.Port = 587;
            smtp.Credentials = new System.Net.NetworkCredential("konyvesarmand", "qcrnbbsskbshovcg");
            smtp.EnableSsl = true;
            smtp.Send(uzenet);

            MessageBox.Show("Jelszavat sikeresen frissitettuk egy generalt ideiglenes jelszora! A jelszot elkuldtuk regisztralt e-mail cimere! Kerem az elso belepes utan valtoztassa meg a [Felhasznalo adatai] menupont segitsegevel!", "Adatait sikeresen frissitettuk!", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void buttonJelszoVisszaABejelentkezeshez_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
