# Szakdolgozat implementaciohoz felhasznalt forrasok
### Keszitette: Bozsik Armand Viktor

A szakdolgozatomban felhasznalt forrasokat az alabbi dokumentumban (illetve az elkeszult programom Forrasok menupontjaban) jegyzem.

# Adatforrasok

* Az adatbazisban talalhato felhasznaloi informaciok a FakeNameGenerator Order in Bulk ingyenes szolgaltatasaval keszultek a dolgozatban elvart Excel (xlsx) formatumban, majd ebbol a programcsomag altal CSV (Comma Separated Values) keszult.

A FakeNameGenerator FAQ menupontja az alabbiak szerint fogalmaz (__Hozzaferes datuma:__ 2018. 10. 24.):

> Can I use your identities in my book, on my website, in my movie, in my video game, etc?

> Absolutely! Please be sure to review the [license](https://www.fakenamegenerator.com/license.php) first. You are required to give attribution to the Fake Name Generator for any information you use from our website.

A hivatkozott licencfeltetelek (__Hozzaferes datuma:__ 2018. 10. 24.):

Fake Name Generator™ identities, the Fake Name Generator website, and all Fake Name Generator tools are copyright © 2006-2018 Corban Works, LLC. These items may only be copied or redistributed according to the terms of the license(s) presented on this page.
Fake Name Generator Identities

Fake Name Generator identities are dual-licensed under the GPLv3 and Creative Commons Attribution-Share Alike 3.0 United States licenses. You may pick either license, but you must comply fully with the license you choose. Please see below for legal statements regarding these licences.
Creative Commons Attribution-Share Alike 3.0 United States

Fake Name Generator identities by the Fake Name Generator are licensed under a Creative Commons Attribution-Share Alike 3.0 United States License.
GPLv3

The Fake Name Generator identities is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.

Pursuant to section 7 of the GPL, we require that you attribute Fake Name Generator <http://www.fakenamegenerator.com> for any information you use from the Fake Name Generator website.

# Felhasznaloi felulet

* [FontAwesome.WPF](https://github.com/charri/Font-Awesome-WPF) (NuGet [csomag](), igy a projekt reszet kepezi. A FontAwesome.WPF *charri* munkaja. A licencfeltetlek az alabbiak (__Hozzaferes datuma: 2018. 10. 24.__):

> The MIT License (MIT)

> Copyright (c) 2014-2016 charri

> Permission is hereby granted, free of charge, to any person obtaining a copy
> of this software and associated documentation files (the "Software"), to deal
> in the Software without restriction, including without limitation the rights
> to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
> copies of the Software, and to permit persons to whom the Software is
> furnished to do so, subject to the following conditions:

> The above copyright notice and this permission notice shall be included in all
> copies or substantial portions of the Software.

> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
> IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
> FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
> AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
> LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
> OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
> SOFTWARE.

(A szoveg eredetileg a [LICENSE](https://github.com/charri/Font-Awesome-WPF/blob/master/LICENSE)-ben olvashato)

A FontAwesome a Fonticon Inc. munkaja es a [kozolt licencfeltetelek](https://fontawesome.com/license) vonatkoznak a felhasznalasra. (__Hozzaferes datuma: 2018.10.24.__)