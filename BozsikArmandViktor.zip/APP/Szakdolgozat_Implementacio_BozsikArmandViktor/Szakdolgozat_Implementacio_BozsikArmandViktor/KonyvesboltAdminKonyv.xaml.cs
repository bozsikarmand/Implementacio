﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Szakdolgozat_Implementacio_BozsikArmandViktor
{
    /// <summary>
    /// Interaction logic for KonyvesboltAdminKonyv.xaml
    /// </summary>
    public partial class KonyvesboltAdminKonyv : Window
    {
        private int ID;
        public KonyvesboltAdminKonyv(int ID)
        {
            this.ID = ID;
            InitializeComponent();
            DataGridFeltoltese();
        }

        /// <summary>
        /// Letrehozom a DataContextet, mely az objektum-relacios modellt reprezentalja
        /// Az osszes felhasznalo lekerdezesre kerul
        /// A dataGrid forrasa a lekerdezes eredmenytablaja lesz
        /// </summary>
        private void DataGridFeltoltese()
        {
            AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
            var konyv = from k in adatbazis.Konyvs
                        select k;

            dataGridKonyv.ItemsSource = konyv;

            var szerzo = from sz in adatbazis.Szerzos
                         select sz;

            dataGridSzerzo.ItemsSource = szerzo;

            var konyvSzerzo = from ksz in adatbazis.KonyvSzerzos
                              select ksz;

            dataGridKonyvSzerzo.ItemsSource = konyvSzerzo;
        }

        /// <summary>
        /// Letrehozom a DataContextet
        /// Eltarolom a felhasznalo altal kivalasztott sort
        /// A sorbol kivalasztom az ID-t
        /// Az adatbazis konyv tablajabol kivalasztom azokat a rekordokat, ahol az ID es a sor ID-ja egyezik.
        /// A felhasznalo objektumnak ertekul adom a dataGrid megfelelo oszlopait
        /// Rogzitem a valtoztatasokat a kivalasztott elemen
        /// Visszajelzek a felhasznalonak
        /// Frissitem a dataGrid-et
        /// Ha hiba tortenik, lekezelem
        /// </summary>
        private void DataGridElemFrissitese()
        {
            try
            {
                AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
                Konyv konyvSora = dataGridKonyv.SelectedItem as Konyv;

                Konyv konyv = (from k in adatbazis.Konyvs
                               where k.ID == konyvSora.ID
                               select k).Single();

                konyv.ISBN = konyvSora.ISBN;
                konyv.KiadasiEv = konyvSora.KiadasiEv;
                konyv.Kiado = konyvSora.Kiado;
                konyv.Oldalszam = konyvSora.Oldalszam;
                konyv.Fajlmeret = konyvSora.Fajlmeret;
                konyv.Ar = konyvSora.Ar;
                konyv.Mufaj = konyvSora.Mufaj;
                konyv.Almufaj = konyvSora.Almufaj;
                konyv.Nyelv = konyvSora.Nyelv;
                konyv.Cim = konyvSora.Cim;

                Szerzo szerzoSora = dataGridSzerzo.SelectedItem as Szerzo;

                var szerzo = (from sz in adatbazis.Szerzos
                              where sz.ID == szerzoSora.ID
                              select sz).Single();

                szerzo.KonyvISBN = szerzoSora.KonyvISBN;
                szerzo.Szerzonev = szerzoSora.Szerzonev;

                KonyvSzerzo konyvSzerzoSora = dataGridKonyvSzerzo.SelectedItem as KonyvSzerzo;

                var konyvSzerzo = (from ksz in adatbazis.KonyvSzerzos
                                   where ksz.KonyvID == konyvSzerzoSora.KonyvID && ksz.SzerzoID == konyvSzerzoSora.SzerzoID
                                   select ksz).Single();

                if (konyv.ID == konyvSzerzo.KonyvID && konyvSzerzo.SzerzoID == szerzo.ID)
                {
                    adatbazis.SubmitChanges();
                    MessageBox.Show("Az elemek sikeresen frissitve!");
                    DataGridFeltoltese();
                }
                else
                {
                    MessageBox.Show("HIBA!");
                }
                
            }
            catch (SqlException)
            {
                MessageBox.Show("Ilyen ISBN szamon mar van termek bejegyezve, igy a frissites elvetesre kerul!", "HIBA!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Letrehozom a DataContextet
        /// Eltarolom a felhasznalo altal kivalasztott sort
        /// A sorbol kivalasztom az ID-t
        /// Az adatbazis konyv tablajabol kivalasztom azokat a rekordokat, ahol az ID es a sor ID-ja egyezik.
        /// Torlom a kivalasztott elemet
        /// Elkuldom a valtozasokat az adatbazis szerver fele
        /// Visszajelzek a felhasznalonak
        /// Frissitem a dataGrid-et
        /// Ha hiba tortenik, lekezelem
        /// </summary>
        private void DataGridElemTorlese()
        {
            try
            {
                AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
                Konyv konyvSora = dataGridKonyv.SelectedItem as Konyv;

                var konyv = (from k in adatbazis.Konyvs
                             where k.ID == konyvSora.ID
                             select k).Single();

                Szerzo szerzoSora = dataGridSzerzo.SelectedItem as Szerzo;

                var szerzo = (from sz in adatbazis.Szerzos
                              where sz.ID == szerzoSora.ID
                              select sz).Single();

                KonyvSzerzo konyvSzerzoSora = dataGridKonyvSzerzo.SelectedItem as KonyvSzerzo;

                var konyvSzerzo = (from ksz in adatbazis.KonyvSzerzos
                                   where ksz.KonyvID == konyvSzerzoSora.KonyvID && ksz.SzerzoID == konyvSzerzoSora.SzerzoID
                                   select ksz).Single();

                if (konyv.ID == konyvSzerzo.KonyvID && konyvSzerzo.SzerzoID == szerzo.ID)
                {
                    adatbazis.Konyvs.DeleteOnSubmit(konyv);
                    adatbazis.KonyvSzerzos.DeleteOnSubmit(konyvSzerzo);
                    adatbazis.Szerzos.DeleteOnSubmit(szerzo);
                    adatbazis.SubmitChanges();
                    MessageBox.Show("Az elemek sikeresen torolve!");
                    DataGridFeltoltese();
                }
                else
                {
                    MessageBox.Show("HIBA!");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("A konyv mar felhasznalo(k)hoz tartozik, igy nem torolheto!", "Figyelem!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Letrehozom a DataContext-et
        /// Letrehozok egy uj konyv objektumot
        /// Ertekul adom az objektumnak a beviteli mezok erteket
        /// Az uj rekordot beillesztem az adatbazisba
        /// Elkuldom a valtozasokat az adatbazis szerver fele
        /// Visszajelzek a felhasznalonak
        /// Frissitem a dataGrid-et
        /// Ha hiba tortenik, lekezelem
        /// </summary>
        private void DataGridElemHozzaadasa()
        {
            try
            {
                AdatbazisOsztalyDataContext adatbazis = new AdatbazisOsztalyDataContext();
                Konyv konyv = new Konyv();

                konyv.ISBN = textBoxISBN.Text;
                konyv.KiadasiEv = Convert.ToInt16(textBoxKiadasiEv.Text);
                konyv.Kiado = textBoxKiado.Text;
                konyv.Oldalszam = Convert.ToInt16(textBoxOldalszam.Text);
                konyv.Fajlmeret = Convert.ToInt32(textBoxFajlmeret.Text);
                konyv.Ar = Convert.ToInt32(textBoxAr.Text);
                konyv.Mufaj = textBoxMufaj.Text;
                konyv.Almufaj = textBoxAlmufaj.Text;
                konyv.Nyelv = textBoxNyelv.Text;
                konyv.Cim = textBoxCim.Text;

                adatbazis.Konyvs.InsertOnSubmit(konyv);

                Szerzo szerzo = new Szerzo();

                szerzo.KonyvISBN = konyv.ISBN;
                szerzo.Szerzonev = textBoxSzerzo.Text;

                adatbazis.Szerzos.InsertOnSubmit(szerzo);

                adatbazis.SubmitChanges();

                KonyvSzerzo konyvSzerzo = new KonyvSzerzo();

                konyvSzerzo.SzerzoID = szerzo.ID;
                konyvSzerzo.KonyvID = konyv.ID;
                
                adatbazis.KonyvSzerzos.InsertOnSubmit(konyvSzerzo);

                adatbazis.SubmitChanges();
                MessageBox.Show("Az elemek sikeresen hozzaadva!");
                DataGridFeltoltese();
            }
            catch (SqlException)
            {
                MessageBox.Show("Ilyen ISBN szamon mar van termek bejegyezve!", "HIBA!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// dataGrid frissitese modositas utan
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonModositas_Click(object sender, RoutedEventArgs e)
        {
            DataGridElemFrissitese();
        }

        /// <summary>
        /// dataGrid elem torlese
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonTorles_Click(object sender, RoutedEventArgs e)
        {
            DataGridElemTorlese();
        }

        /// <summary>
        /// dataGrid elem hozzadasa
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonHozzaadas_Click(object sender, RoutedEventArgs e)
        {
            DataGridElemHozzaadasa();
        }

        private void menuItemSzerzo_Click(object sender, RoutedEventArgs e)
        {
            KonuvesboltAdminSzerzo konuvesboltAdminSzerzo = new KonuvesboltAdminSzerzo(ID);
            konuvesboltAdminSzerzo.Show();
            this.Close();
        }

        private void menuItemFelhasznalo_Click(object sender, RoutedEventArgs e)
        {
            KonuvesboltAdminFelhasznalo konuvesboltAdminFelhasznalo = new KonuvesboltAdminFelhasznalo(ID);
            konuvesboltAdminFelhasznalo.Show();
            this.Close();
        }

        private void buttonVisszaAdminFooldalra_Click(object sender, RoutedEventArgs e)
        {
            KonyvtarFoablak konyvesboltAdminFoablak = new KonyvtarFoablak(ID);
            konyvesboltAdminFoablak.Show();
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dataGridKonyv.CanUserAddRows = false;
            dataGridKonyvSzerzo.CanUserAddRows = false;
            dataGridSzerzo.CanUserAddRows = false;
        }
    }
}
